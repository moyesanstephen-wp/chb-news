// $CHbabastevo NEWS INTELLIGENCE - Stage 5A test/stub Normaliser
// Zero-dependency Node.js HTTP server that returns the frozen chb.newsintel.v1
// schema with deterministic test data. THIS IS TEST/STUB DATA - not a real
// provider. feed_kind stays FIXTURE/simulated so the client never treats it as
// genuine live market news.
//
// For MT4 WebRequest you need HTTPS with a whitelisted domain. Options:
//   (b) EASIEST - host the static file chb_newsintel_v1.json on any HTTPS static
//       host (GitHub raw, Cloudflare Pages, Netlify) and point NI_NormaliserURL
//       at it. No server needed. server_utc is then fixed (status may show STALE
//       depending on freshness policy - fine for a transport test).
//   This server is provided for the "fresh server_utc" variant or a VPS/tunnel.
//
// Run:  node server.js   (listens on :8080, path /v1/feed)
// Put behind TLS (caddy/nginx/ngrok) so MT4 can reach it over HTTPS.

const http = require('http');

// deterministic base payload (mirrors the frozen fixture values)
function payload() {
  const now = Math.floor(Date.now() / 1000);
  return {
    schema: "chb.newsintel.v1",
    feed_kind: "FIXTURE",          // STUB/TEST data - not a real provider
    simulated: true,               // client shows "simulated" guard
    server_utc: now,               // fresh stamp so status computes LIVE
    status: "LIVE",
    tz_note: "server_utc is unix epoch UTC; client converts per NI_Timezone",
    events: [
      { id:"eur-sentix",   utc: now-3600, currency:"EUR", country:"EU", name:"Sentix Investor Confidence", impact:1, actual:"", forecast:"", previous:"", url:"" },
      { id:"usd-ppi",      utc: now+120,  currency:"USD", country:"US", name:"PPI m/m",                    impact:3, actual:"", forecast:"0.2%", previous:"0.1%", url:"" },
      { id:"usd-fed",      utc: now+180,  currency:"USD", country:"US", name:"Fed Interest Rate Decision", impact:3, actual:"", forecast:"5.50%", previous:"5.50%", url:"" },
      { id:"gbp-cpi",      utc: now+300,  currency:"GBP", country:"GB", name:"CPI y/y",                    impact:3, actual:"", forecast:"2.1%", previous:"2.0%", url:"" },
      { id:"usd-fomc",     utc: now+600,  currency:"USD", country:"US", name:"FOMC Press Conference",      impact:3, actual:"", forecast:"", previous:"", url:"" },
      { id:"eur-ecb",      utc: now+900,  currency:"EUR", country:"EU", name:"ECB President Speech",       impact:2, actual:"", forecast:"", previous:"", url:"" },
      { id:"xau-etf",      utc: now+1800, currency:"XAU", country:"",   name:"Gold ETF Flows (weekly)",    impact:1, actual:"", forecast:"", previous:"", url:"" },
      { id:"nzd-rbnz",     utc: now+3600, currency:"NZD", country:"NZ", name:"RBNZ Official Cash Rate",    impact:3, actual:"", forecast:"5.50%", previous:"5.50%", url:"" }
    ],
    headlines: [
      { utc: now-120, currency:"USD", title:"Dollar strengthens ahead of Fed", impact:2, sentiment:0.3,  source:"Stub Newswire", url:"" },
      { utc: now-200, currency:"EUR", title:"Euro steady as ECB speech nears", impact:1, sentiment:0.0,  source:"Stub Newswire", url:"" },
      { utc: now-260, currency:"XAU", title:"Gold rises on safe-haven bid",    impact:2, sentiment:0.4,  source:"Stub Metals Desk", url:"" },
      { utc: now-320, currency:"GBP", title:"Sterling softens before CPI",     impact:1, sentiment:-0.2, source:"Stub Newswire", url:"" },
      { utc: now-380, currency:"JPY", title:"Yen firms as risk appetite dips", impact:2, sentiment:0.1,  source:"Stub FX Desk", url:"" }
    ],
    heat: [
      { currency:"USD", score:67, band:"HIGH" },
      { currency:"EUR", score:13, band:"LOW" },
      { currency:"GBP", score:33, band:"LOW" },
      { currency:"JPY", score:12, band:"LOW" },
      { currency:"CHF", score:3,  band:"LOW" },
      { currency:"CAD", score:15, band:"LOW" },
      { currency:"AUD", score:6,  band:"LOW" },
      { currency:"NZD", score:14, band:"LOW" },
      { currency:"XAU", score:10, band:"LOW" }
    ],
    next_high_impact: { id:"usd-fed", utc: now+180, currency:"USD", name:"Fed Interest Rate Decision", impact:3 }
  };
}

const server = http.createServer((req, res) => {
  if (req.url.startsWith('/v1/feed')) {
    const body = JSON.stringify(payload());
    res.writeHead(200, { 'Content-Type':'application/json', 'Content-Length':Buffer.byteLength(body) });
    res.end(body);
  } else if (req.url.startsWith('/health')) {
    res.writeHead(200, {'Content-Type':'text/plain'}); res.end('ok');
  } else {
    res.writeHead(404, {'Content-Type':'text/plain'}); res.end('not found');
  }
});
const PORT = process.env.PORT || 8080;
server.listen(PORT, () => console.log('CHB stub Normaliser on :'+PORT+' path /v1/feed'));
