//+------------------------------------------------------------------+
//| CHB_NewsIntel_Engine.mq4                                         |
//| $CHbabastevo NEWS INTELLIGENCE - Phase 3 ENGINE (engine only)     |
//|                                                                   |
//| Reads the frozen chb.newsintel.v1 fixture JSON from MQL4/Files/,  |
//| parses it into flat in-memory stores, and enforces every Phase 3  |
//| safety rule. ZERO chart objects. No WebRequest. No UI. No PowerMap|
//| dependency. NI_ prefix is RESERVED for Phase 4 (unused here).     |
//|                                                                   |
//| Build note: this is the ENGINE layer. It creates no ObjectCreate, |
//| no labels, no panels. It exposes callable engine functions + an   |
//| OnInit self-test harness that runs the acceptance tests against   |
//| the fixture and prints PASS/FAIL to the Experts log.              |
//+------------------------------------------------------------------+
#property copyright "CHbabastevo"
#property version   "3.11"
#property strict
#property indicator_chart_window
#property indicator_plots 0
#property indicator_buffers 0

//====================================================================
// SCHEMA CONSTANTS (frozen chb.newsintel.v1)
//====================================================================
#define NI_SCHEMA_ID   "chb.newsintel.v1"

// Supported currency universe - SAME universe as FX PowerMap.
// XAU is first-class (index 8), never dropped.
#define NI_NCCY 9
string  NI_CCY[NI_NCCY];   // filled in NI_InitConst()

// Impact encoding (matches server): 3=HIGH 2=MED 1=LOW 0=UNKNOWN
#define NI_IMP_HIGH 3
#define NI_IMP_MED  2
#define NI_IMP_LOW  1
#define NI_IMP_UNK  0

// Feed status (production capability; orthogonal to feed_kind)
#define NI_ST_LIVE    "LIVE"
#define NI_ST_STALE   "STALE"
#define NI_ST_OFFLINE "OFFLINE"

// Feed kind (fixture vs production)
#define NI_KIND_FIXTURE    "FIXTURE"
#define NI_KIND_PRODUCTION "PRODUCTION"

// Event lifecycle states (derived from countdown)
#define NI_EV_UPCOMING  0
#define NI_EV_NOW       1
#define NI_EV_COMPLETED 2

// Timezone interpretation for countdown/display
#define NI_TZ_BROKER 0
#define NI_TZ_LOCAL  1
#define NI_TZ_UTC    2

// EVENT NOW window (seconds either side of event.utc where state == NOW)
#define NI_NOW_WINDOW_SEC 900   // 15 minutes, consistent with heat A-window

// Store capacities (flat arrays; generous fixed caps avoid dynamic 2D)
#define NI_MAX_EVENTS    256
#define NI_MAX_HEADLINES 256

//====================================================================
// INPUTS
//====================================================================
input string NI_FixtureFile = "chb_newsintel_fixture_default.json"; // in MQL4/Files/
input int    NI_Timezone    = NI_TZ_BROKER;   // 0=Broker 1=Local 2=UTC
input bool   NI_RunSelfTest = true;           // run acceptance harness on init

//====================================================================
// GLOBAL STORES (flat, parallel arrays - MQL4-friendly, no 2D-dynamic)
//====================================================================
// --- top-level feed scalars ---
string g_schema;
string g_feed_kind;
bool   g_simulated;
long   g_server_utc;
string g_status;
string g_tz_note;

// --- parse/consume state ---
bool   g_feedValid;        // parsed & schema-safe
bool   g_feedSimulated;    // enforced safety flag (see NI_EnforceFixtureGuard)
string g_lastError;        // last parser/consumer error text
int    g_connState;        // mirrors g_status as an int for the state machine

// --- events store (parallel arrays) ---
int    g_nEvents;
string ev_id[];
long   ev_utc[];
string ev_currency[];
string ev_country[];
string ev_name[];
int    ev_impact[];
string ev_actual[];
string ev_forecast[];
string ev_previous[];
string ev_url[];

// --- headlines store (parallel arrays) ---
int    g_nHeadlines;
long   hl_utc[];
string hl_currency[];
string hl_title[];
int    hl_impact[];
bool   hl_hasSentiment[];  // false when sentiment == null
double hl_sentiment[];     // valid only when hl_hasSentiment==true
string hl_source[];
string hl_url[];

// --- heat store (always 9, one per currency) ---
int    g_nHeat;
string ht_currency[];
int    ht_score[];
string ht_band[];

// --- next_high_impact (single, or none) ---
bool   g_hasNextHigh;
string nh_id;
string nh_currency;
string nh_name;
long   nh_utc;

// --- lightweight strength context (independent engine) ---
double g_strength[];   // 0..100 per NI_CCY index, -1 if unavailable
int    g_strengthDir[]; // +1 up / 0 flat / -1 down, per NI_CCY
string g_goldSymbol="";  // broker gold symbol resolved for the XAU read ("" if none)

//====================================================================
// CONSTANT INIT
//====================================================================
void NI_InitConst()
{
   NI_CCY[0]="USD"; NI_CCY[1]="EUR"; NI_CCY[2]="GBP"; NI_CCY[3]="JPY";
   NI_CCY[4]="CHF"; NI_CCY[5]="CAD"; NI_CCY[6]="AUD"; NI_CCY[7]="NZD";
   NI_CCY[8]="XAU";
}

// index of a currency code in NI_CCY, or -1
int NI_CcyIndex(string c)
{
   for(int i=0;i<NI_NCCY;i++) if(NI_CCY[i]==c) return i;
   return -1;
}

//====================================================================
// STORE ALLOCATION
// MQL4 dynamic arrays start at size 0; the parser indexes ev_*/hl_*/ht_*
// directly, so they MUST be pre-sized to their caps before any parse.
//====================================================================
void NI_InitStores()
{
   ArrayResize(ev_id,       NI_MAX_EVENTS);
   ArrayResize(ev_utc,      NI_MAX_EVENTS);
   ArrayResize(ev_currency, NI_MAX_EVENTS);
   ArrayResize(ev_country,  NI_MAX_EVENTS);
   ArrayResize(ev_name,     NI_MAX_EVENTS);
   ArrayResize(ev_impact,   NI_MAX_EVENTS);
   ArrayResize(ev_actual,   NI_MAX_EVENTS);
   ArrayResize(ev_forecast, NI_MAX_EVENTS);
   ArrayResize(ev_previous, NI_MAX_EVENTS);
   ArrayResize(ev_url,      NI_MAX_EVENTS);

   ArrayResize(hl_utc,          NI_MAX_HEADLINES);
   ArrayResize(hl_currency,     NI_MAX_HEADLINES);
   ArrayResize(hl_title,        NI_MAX_HEADLINES);
   ArrayResize(hl_impact,       NI_MAX_HEADLINES);
   ArrayResize(hl_hasSentiment, NI_MAX_HEADLINES);
   ArrayResize(hl_sentiment,    NI_MAX_HEADLINES);
   ArrayResize(hl_source,       NI_MAX_HEADLINES);
   ArrayResize(hl_url,          NI_MAX_HEADLINES);

   ArrayResize(ht_currency, NI_NCCY);
   ArrayResize(ht_score,    NI_NCCY);
   ArrayResize(ht_band,     NI_NCCY);

   ArrayResize(g_strength,    NI_NCCY);
   ArrayResize(g_strengthDir, NI_NCCY);
}
//+------------------------------------------------------------------+
//| 10_mapping.mqh - currency/asset resolution (Phase 2 rules)        |
//| Mirrors the server's resolveCurrency: canonical -> gold aliases   |
//| -> country/region. Returns "" when unmappable (never invents).    |
//| XAU is first-class; GOLD / XAUUSD / XAUUSD.pro etc. -> "XAU".      |
//+------------------------------------------------------------------+

// uppercase a copy (MQL4 StringToUpper is in-place + returns bool; never assign it)
string NI_Upper(string s)
{
   string t = s;
   StringToUpper(t);
   return t;
}

string NI_Trim(string s)
{
   string t = s;
   StringTrimLeft(t);
   StringTrimRight(t);
   return t;
}

bool NI_InArray(string needle, string &arr[], int n)
{
   for(int i=0;i<n;i++) if(arr[i]==needle) return true;
   return false;
}

// Resolve loose provider terminology to a supported currency code, or "".
string NI_ResolveCurrency(string raw)
{
   string s = NI_Upper(NI_Trim(raw));
   if(s=="") return "";

   // already canonical?
   if(NI_CcyIndex(s)>=0) return s;

   // gold terminology -> XAU
   string gold[9];
   gold[0]="XAU"; gold[1]="GOLD"; gold[2]="XAUUSD"; gold[3]="XAU/USD";
   gold[4]="XAUUSDM"; gold[5]="XAUUSD.A"; gold[6]="XAUUSD.PRO";
   gold[7]="GOLDSPOT"; gold[8]="GLD";
   if(NI_InArray(s, gold, 9)) return "XAU";

   // country / region -> currency
   if(s=="US"||s=="USA"||s=="UNITED STATES") return "USD";
   if(s=="EU"||s=="EA"||s=="EURO AREA"||s=="EUROZONE"||s=="GERMANY"||s=="FRANCE") return "EUR";
   if(s=="UK"||s=="GB"||s=="UNITED KINGDOM"||s=="BRITAIN") return "GBP";
   if(s=="JP"||s=="JAPAN") return "JPY";
   if(s=="CH"||s=="SWITZERLAND") return "CHF";
   if(s=="CA"||s=="CANADA") return "CAD";
   if(s=="AU"||s=="AUSTRALIA") return "AUD";
   if(s=="NZ"||s=="NEW ZEALAND") return "NZD";

   return "";   // unmapped -> "" (caller keeps it, never invented)
}
//+------------------------------------------------------------------+
//| 20_parser.mqh - deterministic JSON parser for chb.newsintel.v1    |
//|                                                                   |
//| NOT a generic JSON framework. A small hand-rolled tokenizer that  |
//| walks the frozen flat schema: top-level scalars, events[],        |
//| headlines[], heat[], next_high_impact (object|null). It handles   |
//| strings (with \" \\ \/ \n \t \uXXXX-basic escapes), numbers,      |
//| booleans, null, and nested objects/arrays only as deep as the     |
//| schema requires (one array of flat objects per section).          |
//|                                                                   |
//| Safety: rejects invalid JSON, warns/refuses on schema mismatch,   |
//| and validates required top-level fields. Never throws; returns    |
//| false and sets g_lastError.                                       |
//+------------------------------------------------------------------+

// ---- low-level cursor over the JSON text ----
string P_src;
int    P_pos;
int    P_len;
bool   P_ok;

void P_init(string s){ P_src=s; P_pos=0; P_len=StringLen(s); P_ok=true; }

void P_fail(string why)
{
   if(P_ok){ P_ok=false; g_lastError=why+" @pos "+IntegerToString(P_pos); }
}

// peek current char code (-1 at end)
int P_peek()
{
   if(P_pos>=P_len) return -1;
   return StringGetCharacter(P_src,P_pos);
}

void P_skipWs()
{
   while(P_pos<P_len)
   {
      int c=StringGetCharacter(P_src,P_pos);
      if(c==' '||c=='\t'||c=='\n'||c=='\r'){ P_pos++; continue; }
      break;
   }
}

bool P_expect(int ch)
{
   P_skipWs();
   if(P_peek()!=ch){ P_fail("expected '"+CharToString((uchar)ch)+"'"); return false; }
   P_pos++;
   return true;
}

// parse a JSON string token (assumes current char is the opening quote)
string P_parseString()
{
   string out="";
   P_skipWs();
   if(P_peek()!='"'){ P_fail("expected string"); return out; }
   P_pos++; // consume opening quote
   while(P_pos<P_len)
   {
      int c=StringGetCharacter(P_src,P_pos); P_pos++;
      if(c=='"') return out;                 // closing quote
      if(c=='\\')
      {
         if(P_pos>=P_len){ P_fail("bad escape"); return out; }
         int e=StringGetCharacter(P_src,P_pos); P_pos++;
         if(e=='"')  out+="\"";
         else if(e=='\\') out+="\\";
         else if(e=='/')  out+="/";
         else if(e=='n')  out+="\n";
         else if(e=='t')  out+="\t";
         else if(e=='r')  out+="\r";
         else if(e=='b')  out+=CharToString((uchar)8);
         else if(e=='f')  out+=CharToString((uchar)12);
         else if(e=='u')
         {
            // basic \uXXXX -> keep ASCII if <128 else '?'; schema is ASCII anyway
            if(P_pos+4>P_len){ P_fail("bad \\u"); return out; }
            int code=0;
            for(int k=0;k<4;k++)
            {
               int h=StringGetCharacter(P_src,P_pos); P_pos++;
               int d=0;
               if(h>='0'&&h<='9') d=h-'0';
               else if(h>='a'&&h<='f') d=10+(h-'a');
               else if(h>='A'&&h<='F') d=10+(h-'A');
               else { P_fail("bad hex in \\u"); return out; }
               code=code*16+d;
            }
            if(code<128) out+=CharToString((uchar)code); else out+="?";
         }
         else { P_fail("unknown escape"); return out; }
      }
      else out+=CharToString((uchar)c);
   }
   P_fail("unterminated string");
   return out;
}

// parse a bare token (number/true/false/null) up to a delimiter; returns raw text
string P_parseBareToken()
{
   P_skipWs();
   int start=P_pos;
   while(P_pos<P_len)
   {
      int c=StringGetCharacter(P_src,P_pos);
      if(c==','||c=='}'||c==']'||c==' '||c=='\t'||c=='\n'||c=='\r') break;
      P_pos++;
   }
   return StringSubstr(P_src,start,P_pos-start);
}

// skip a whole JSON value (object/array/string/bare) - used to ignore unknown keys
void P_skipValue()
{
   P_skipWs();
   int c=P_peek();
   if(c=='"'){ P_parseString(); return; }
   if(c=='{')
   {
      P_pos++; // {
      P_skipWs();
      if(P_peek()=='}'){ P_pos++; return; }
      while(P_ok)
      {
         P_parseString();          // key
         P_expect(':');
         P_skipValue();            // value
         P_skipWs();
         int d=P_peek();
         if(d==','){ P_pos++; continue; }
         if(d=='}'){ P_pos++; break; }
         P_fail("bad object in skip"); break;
      }
      return;
   }
   if(c=='[')
   {
      P_pos++; // [
      P_skipWs();
      if(P_peek()==']'){ P_pos++; return; }
      while(P_ok)
      {
         P_skipValue();
         P_skipWs();
         int d=P_peek();
         if(d==','){ P_pos++; continue; }
         if(d==']'){ P_pos++; break; }
         P_fail("bad array in skip"); break;
      }
      return;
   }
   // bare
   P_parseBareToken();
}
//+------------------------------------------------------------------+
//| 30_parse_feed.mqh - schema-aware parse of chb.newsintel.v1        |
//| Consumes the tokenizer to fill the flat global stores. Validates  |
//| required top-level fields; warns/refuses on schema mismatch.      |
//+------------------------------------------------------------------+

// helpers to interpret bare tokens
bool  NI_TokenIsNull(string t){ return (t=="null"); }
long  NI_TokenToLong(string t){ return (long)StringToInteger(t); }
double NI_TokenToDouble(string t){ return StringToDouble(t); }
bool  NI_TokenToBool(string t){ return (t=="true"); }

// Parse one event object into the store at index g_nEvents (advances it).
void NI_ParseEventObject()
{
   if(g_nEvents>=NI_MAX_EVENTS){ P_skipValue(); return; }
   int i=g_nEvents;
   // defaults
   ev_id[i]=""; ev_utc[i]=0; ev_currency[i]=""; ev_country[i]="";
   ev_name[i]=""; ev_impact[i]=NI_IMP_UNK; ev_actual[i]="";
   ev_forecast[i]=""; ev_previous[i]=""; ev_url[i]="";
   bool hasUtc=false;

   P_expect('{');
   P_skipWs();
   if(P_peek()=='}'){ P_pos++; }
   else
   {
      while(P_ok)
      {
         string key=P_parseString();
         P_expect(':');
         P_skipWs();
         if(key=="id")            ev_id[i]=P_parseString();
         else if(key=="currency") ev_currency[i]=NI_ResolveCurrency(P_parseString());
         else if(key=="country")  ev_country[i]=P_parseString();
         else if(key=="name")     ev_name[i]=P_parseString();
         else if(key=="actual")   ev_actual[i]=P_parseString();
         else if(key=="forecast") ev_forecast[i]=P_parseString();
         else if(key=="previous") ev_previous[i]=P_parseString();
         else if(key=="url")      ev_url[i]=P_parseString();
         else if(key=="utc")      { string t=P_parseBareToken(); ev_utc[i]=NI_TokenToLong(t); hasUtc=true; }
         else if(key=="impact")   { string t=P_parseBareToken(); ev_impact[i]=(int)NI_TokenToLong(t); }
         else                     P_skipValue();     // unknown key ignored
         P_skipWs();
         int d=P_peek();
         if(d==','){ P_pos++; continue; }
         if(d=='}'){ P_pos++; break; }
         P_fail("bad event object"); break;
      }
   }
   // A row with no/invalid utc is unsafe -> skip it (defensive; server already drops)
   if(!hasUtc || ev_utc[i]<=0){ return; }
   g_nEvents++;
}

void NI_ParseHeadlineObject()
{
   if(g_nHeadlines>=NI_MAX_HEADLINES){ P_skipValue(); return; }
   int i=g_nHeadlines;
   hl_utc[i]=0; hl_currency[i]=""; hl_title[i]=""; hl_impact[i]=NI_IMP_UNK;
   hl_hasSentiment[i]=false; hl_sentiment[i]=0.0; hl_source[i]=""; hl_url[i]="";
   bool hasUtc=false;

   P_expect('{');
   P_skipWs();
   if(P_peek()=='}'){ P_pos++; }
   else
   {
      while(P_ok)
      {
         string key=P_parseString();
         P_expect(':');
         P_skipWs();
         if(key=="currency")    hl_currency[i]=NI_ResolveCurrency(P_parseString());
         else if(key=="title")  hl_title[i]=P_parseString();
         else if(key=="source") hl_source[i]=P_parseString();
         else if(key=="url")    hl_url[i]=P_parseString();
         else if(key=="utc")    { string t=P_parseBareToken(); hl_utc[i]=NI_TokenToLong(t); hasUtc=true; }
         else if(key=="impact") { string t=P_parseBareToken(); hl_impact[i]=(int)NI_TokenToLong(t); }
         else if(key=="sentiment")
         {
            P_skipWs();
            if(P_peek()=='"'){ P_parseString(); hl_hasSentiment[i]=false; }   // string -> treat as none
            else
            {
               string t=P_parseBareToken();
               if(NI_TokenIsNull(t)){ hl_hasSentiment[i]=false; }
               else { hl_sentiment[i]=NI_TokenToDouble(t); hl_hasSentiment[i]=true; }
            }
         }
         else P_skipValue();
         P_skipWs();
         int d=P_peek();
         if(d==','){ P_pos++; continue; }
         if(d=='}'){ P_pos++; break; }
         P_fail("bad headline object"); break;
      }
   }
   if(!hasUtc || hl_utc[i]<=0){ return; }
   g_nHeadlines++;
}

void NI_ParseHeatObject()
{
   if(g_nHeat>=NI_NCCY){ P_skipValue(); return; }
   int i=g_nHeat;
   ht_currency[i]=""; ht_score[i]=0; ht_band[i]="LOW";
   P_expect('{');
   P_skipWs();
   if(P_peek()=='}'){ P_pos++; }
   else
   {
      while(P_ok)
      {
         string key=P_parseString();
         P_expect(':');
         P_skipWs();
         if(key=="currency")  ht_currency[i]=P_parseString();
         else if(key=="band") ht_band[i]=P_parseString();
         else if(key=="score"){ string t=P_parseBareToken(); ht_score[i]=(int)NI_TokenToLong(t); }
         else P_skipValue();
         P_skipWs();
         int d=P_peek();
         if(d==','){ P_pos++; continue; }
         if(d=='}'){ P_pos++; break; }
         P_fail("bad heat object"); break;
      }
   }
   g_nHeat++;
}

void NI_ParseArray(int which)  // 0=events 1=headlines 2=heat
{
   P_expect('[');
   P_skipWs();
   if(P_peek()==']'){ P_pos++; return; }   // empty array
   while(P_ok)
   {
      if(which==0)      NI_ParseEventObject();
      else if(which==1) NI_ParseHeadlineObject();
      else              NI_ParseHeatObject();
      P_skipWs();
      int d=P_peek();
      if(d==','){ P_pos++; continue; }
      if(d==']'){ P_pos++; break; }
      P_fail("bad array"); break;
   }
}

void NI_ParseNextHigh()  // object or null
{
   P_skipWs();
   if(P_peek()=='n')  // null
   {
      string t=P_parseBareToken();
      if(NI_TokenIsNull(t)){ g_hasNextHigh=false; return; }
      P_fail("bad next_high token"); return;
   }
   // object
   nh_id=""; nh_currency=""; nh_name=""; nh_utc=0;
   bool hasUtc=false;
   P_expect('{');
   P_skipWs();
   if(P_peek()=='}'){ P_pos++; }
   else
   {
      while(P_ok)
      {
         string key=P_parseString();
         P_expect(':');
         P_skipWs();
         if(key=="id")            nh_id=P_parseString();
         else if(key=="currency") nh_currency=P_parseString();
         else if(key=="name")     nh_name=P_parseString();
         else if(key=="utc")      { string t=P_parseBareToken(); nh_utc=NI_TokenToLong(t); hasUtc=true; }
         else P_skipValue();
         P_skipWs();
         int d=P_peek();
         if(d==','){ P_pos++; continue; }
         if(d=='}'){ P_pos++; break; }
         P_fail("bad next_high object"); break;
      }
   }
   g_hasNextHigh = (hasUtc && nh_utc>0);
}

//------------------------------------------------------------------
// Top-level: parse the whole feed object. Returns true if safe.
//------------------------------------------------------------------
bool NI_ParseFeed(string json)
{
   // reset stores
   g_nEvents=0; g_nHeadlines=0; g_nHeat=0; g_hasNextHigh=false;
   g_schema=""; g_feed_kind=""; g_simulated=false; g_server_utc=0;
   g_status=""; g_tz_note="UTC"; g_lastError="";

   bool sawSchema=false, sawServerUtc=false, sawStatus=false, sawKind=false;

   P_init(json);
   P_skipWs();
   if(!P_expect('{')){ g_lastError="not a JSON object: "+g_lastError; return false; }

   P_skipWs();
   if(P_peek()=='}'){ P_pos++; }
   else
   {
      while(P_ok)
      {
         string key=P_parseString();
         if(!P_ok) break;
         P_expect(':');
         P_skipWs();

         if(key=="schema")            { g_schema=P_parseString(); sawSchema=true; }
         else if(key=="feed_kind")    { g_feed_kind=P_parseString(); sawKind=true; }
         else if(key=="status")       { g_status=P_parseString(); sawStatus=true; }
         else if(key=="tz_note")      { g_tz_note=P_parseString(); }
         else if(key=="simulated")    { string t=P_parseBareToken(); g_simulated=NI_TokenToBool(t); }
         else if(key=="server_utc")   { string t=P_parseBareToken(); g_server_utc=NI_TokenToLong(t); sawServerUtc=true; }
         else if(key=="events")       NI_ParseArray(0);
         else if(key=="headlines")    NI_ParseArray(1);
         else if(key=="heat")         NI_ParseArray(2);
         else if(key=="next_high_impact") NI_ParseNextHigh();
         else                         P_skipValue();  // unknown top-level key ignored

         P_skipWs();
         int d=P_peek();
         if(d==','){ P_pos++; continue; }
         if(d=='}'){ P_pos++; break; }
         P_fail("bad top-level object"); break;
      }
   }

   if(!P_ok){ g_lastError="malformed JSON: "+g_lastError; return false; }

   // ---- schema-version safety ----
   if(!sawSchema){ g_lastError="missing required field: schema"; return false; }
   if(g_schema!=NI_SCHEMA_ID){ g_lastError="unsupported schema version: "+g_schema; return false; }

   // ---- required top-level fields ----
   if(!sawServerUtc){ g_lastError="missing required field: server_utc"; return false; }
   if(g_server_utc<=0){ g_lastError="invalid server_utc"; return false; }
   if(!sawStatus){ g_lastError="missing required field: status"; return false; }
   if(g_status!=NI_ST_LIVE && g_status!=NI_ST_STALE && g_status!=NI_ST_OFFLINE)
   { g_lastError="invalid status: "+g_status; return false; }
   if(!sawKind){ g_lastError="missing required field: feed_kind"; return false; }
   if(g_feed_kind!=NI_KIND_FIXTURE && g_feed_kind!=NI_KIND_PRODUCTION)
   { g_lastError="invalid feed_kind: "+g_feed_kind; return false; }

   return true;
}
//+------------------------------------------------------------------+
//| 40_engine.mqh - loader, guards, state machine, countdown, next-hi |
//+------------------------------------------------------------------+

// ---- DIAGNOSTIC (Phase 3 Stage 2): on load failure, print the absolute data
// path the terminal uses and list every file the sandbox can actually see in
// MQL4\Files\. This is Print()-only: it creates no objects, changes no logic,
// and does not affect any acceptance test. It exists purely to resolve the
// err=5004 file-placement question.
void NI_DiagnoseFilesFolder(string wanted)
{
   Print("--- NI DIAGNOSTIC: file load failed, inspecting MQL4\\Files\\ ---");
   Print("   terminal data path : ", TerminalInfoString(TERMINAL_DATA_PATH));
   Print("   common data path    : ", TerminalInfoString(TERMINAL_COMMONDATA_PATH));
   Print("   full expected file  : <data path>\\MQL4\\Files\\", wanted);
   Print("   (the file must sit in the MQL4\\Files\\ folder under the data path above)");

   // enumerate everything the sandbox sees in MQL4\Files\
   string found;
   long   fh;
   int    count=0;
   fh=FileFindFirst("*", found);
   if(fh==INVALID_HANDLE)
   {
      Print("   MQL4\\Files\\ appears EMPTY (or no read access). ",
            "Place ", wanted, " directly in that folder.");
   }
   else
   {
      Print("   files visible to the engine in MQL4\\Files\\:");
      do
      {
         count++;
         Print("      [", count, "] ", found);
      }
      while(FileFindNext(fh, found));
      FileFindClose(fh);
      Print("   total items visible: ", count);
      Print("   -> if you see the fixture above but with a different name/extension");
      Print("      (e.g. .json.txt), rename it to exactly: ", wanted);
   }
   Print("--- END NI DIAGNOSTIC ---");
}

// ---- file loader: read whole fixture from MQL4/Files/ ----
// Reads the file as raw bytes and decodes UTF-8. Avoids narrowing-cast
// warnings by keeping FileSize's ulong result in a ulong and validating
// before use.
bool NI_LoadFixtureFile(string fname, string &outText)
{
   outText="";
   int h=FileOpen(fname, FILE_READ|FILE_BIN);
   if(h==INVALID_HANDLE)
   {
      g_lastError="cannot open file: "+fname+" err="+IntegerToString(GetLastError());
      NI_DiagnoseFilesFolder(fname);   // diagnostic-only; prints path + folder listing
      return false;
   }
   ulong szl=FileSize(h);
   if(szl==0)
   {
      FileClose(h);
      g_lastError="empty file: "+fname;
      return false;
   }
   int sz=(int)szl;
   uchar buf[];
   ArrayResize(buf, sz);
   uint rd=FileReadArray(h, buf, 0, sz);
   FileClose(h);
   if(rd==0)
   {
      g_lastError="file read failed: "+fname;
      return false;
   }
   outText=CharArrayToString(buf, 0, (int)rd, CP_UTF8);
   return true;
}

// ---- FIXTURE SAFETY GUARD ----
// If feed_kind==FIXTURE OR simulated==true, the engine marks the feed simulated
// and must never expose it internally as genuine live market data.
void NI_EnforceFixtureGuard()
{
   g_feedSimulated = (g_feed_kind==NI_KIND_FIXTURE) || (g_simulated==true);
}

// Is this feed safe to treat as real production market data?
// feed_kind and status are INDEPENDENT: PRODUCTION+LIVE is real; anything
// simulated is not, regardless of status.
bool NI_IsGenuineLiveData()
{
   if(g_feedSimulated) return false;
   if(g_feed_kind!=NI_KIND_PRODUCTION) return false;
   if(g_status!=NI_ST_LIVE) return false;
   return true;
}

// ---- CONNECTION STATE MACHINE (mirrors status; independent of feed_kind) ----
void NI_UpdateConnState()
{
   if(g_status==NI_ST_LIVE)         g_connState=0;
   else if(g_status==NI_ST_STALE)   g_connState=1;
   else                             g_connState=2;   // OFFLINE
}
string NI_ConnStateText()
{
   if(g_connState==0) return "LIVE";
   if(g_connState==1) return "STALE";
   return "OFFLINE";
}

// ---- TIMEZONE / NOW ----
// Returns "now" in the epoch-UTC frame so it is directly comparable to *.utc.
// Broker time (TimeCurrent) is converted to UTC via the broker-UTC offset.
// Local machine time (TimeLocal/TimeGMT) gives the true offset; if unavailable
// we fall back to server_utc as the clock (still deterministic for fixtures).
long NI_NowUtc()
{
   // TimeGMT() is UTC from the local machine clock. In the Strategy Tester or
   // when the machine clock is intentionally simulated, prefer server_utc so
   // the fixture stays reproducible.
   long gmt = (long)TimeGMT();
   if(gmt>0) return gmt;
   return g_server_utc;
}

// Convert a UTC epoch to the configured display frame (returns epoch in that
// frame's wall-clock sense for formatting; countdown math always uses UTC).
long NI_ToDisplayFrame(long utc)
{
   if(NI_Timezone==NI_TZ_UTC) return utc;
   if(NI_Timezone==NI_TZ_LOCAL)
   {
      long localOff = (long)TimeLocal() - (long)TimeGMT();
      return utc + localOff;
   }
   // Broker
   long brokerOff = (long)TimeCurrent() - (long)TimeGMT();
   return utc + brokerOff;
}

// ---- COUNTDOWN + EVENT LIFECYCLE ----
// secondsUntil = event.utc - now(UTC). Positive => upcoming.
long NI_SecondsUntil(long eventUtc)
{
   return eventUtc - NI_NowUtc();
}

int NI_EventState(long eventUtc)
{
   long d = NI_SecondsUntil(eventUtc);
   if(d >  NI_NOW_WINDOW_SEC) return NI_EV_UPCOMING;
   if(d < -NI_NOW_WINDOW_SEC) return NI_EV_COMPLETED;
   return NI_EV_NOW;   // within +/- window of event time
}

// Format a countdown as HH:MM:SS for an upcoming event; "" if not upcoming.
string NI_CountdownText(long eventUtc)
{
   long d = NI_SecondsUntil(eventUtc);
   if(d<=0) return "";              // never a positive countdown for expired
   long hh=d/3600; long mm=(d%3600)/60; long ss=d%60;
   return StringFormat("%02d:%02d:%02d", (int)hh,(int)mm,(int)ss);
}

// ---- NEXT HIGH IMPACT consumption ----
// The server pre-resolves next_high_impact, but we re-validate the rule:
// eligible only if event.utc > server_utc. If the provided next-high is
// expired relative to server_utc, we re-scan events for the nearest upcoming
// HIGH. Returns index into events store, or -1, and sets out fields.
int NI_ResolveNextHigh(string &oId, string &oCcy, string &oName, long &oUtc)
{
   oId=""; oCcy=""; oName=""; oUtc=0;

   // trust server next-high ONLY if it satisfies the eligibility rule
   if(g_hasNextHigh && nh_utc > g_server_utc)
   {
      oId=nh_id; oCcy=nh_currency; oName=nh_name; oUtc=nh_utc;
      // find its index if present (best-effort)
      for(int i=0;i<g_nEvents;i++) if(ev_id[i]==nh_id) return i;
      return -1;   // not in store but still valid header info
   }

   // otherwise re-scan events for nearest upcoming HIGH (utc > server_utc)
   int best=-1; long bestUtc=0;
   for(int i=0;i<g_nEvents;i++)
   {
      if(ev_impact[i]!=NI_IMP_HIGH) continue;
      if(ev_utc[i] <= g_server_utc) continue;   // expired never selected
      if(best<0 || ev_utc[i]<bestUtc){ best=i; bestUtc=ev_utc[i]; }
   }
   if(best>=0)
   {
      oId=ev_id[best]; oCcy=ev_currency[best]; oName=ev_name[best]; oUtc=ev_utc[best];
   }
   return best;
}

// ---- HEAT consumption (display only; never recomputed here) ----
int NI_HeatScore(string ccy)
{
   for(int i=0;i<g_nHeat;i++) if(ht_currency[i]==ccy) return ht_score[i];
   return -1;
}
string NI_HeatBand(string ccy)
{
   for(int i=0;i<g_nHeat;i++) if(ht_currency[i]==ccy) return ht_band[i];
   return "";
}
//+------------------------------------------------------------------+
//| 45_embed.mqh - self-writing fixture (write-if-missing, no override)|
//|                                                                   |
//| Phase 3 Stage 2 convenience: if the fixture file is absent from   |
//| MQL4\\Files\\, the engine writes THIS embedded copy there once, then |
//| loads it normally. It NEVER overwrites an existing file - if the  |
//| file is already present, this is skipped entirely. No objects, no |
//| network. The embedded JSON is the exact frozen Phase 2 fixture.   |
//+------------------------------------------------------------------+

// write one line + newline to an open text handle
void NI_W(int h, string s)
{
   FileWriteString(h, s+"\n");
}

// Returns true if the file exists (openable for read) in MQL4\Files\.
bool NI_FixtureExists(string fname)
{
   int h=FileOpen(fname, FILE_READ|FILE_BIN);
   if(h==INVALID_HANDLE) return false;
   FileClose(h);
   return true;
}

// Write the embedded fixture to MQL4\Files\<fname>. Returns true on success.
// NEVER called when the file already exists (see NI_EnsureFixture).
bool NI_WriteEmbeddedFixture(string fname)
{
   int h=FileOpen(fname, FILE_WRITE|FILE_TXT|FILE_ANSI);
   if(h==INVALID_HANDLE)
   {
      Print("NI: could not create fixture file (write) err=", GetLastError());
      return false;
   }
   NI_W(h,"{");
   NI_W(h,"  \"schema\": \"chb.newsintel.v1\",");
   NI_W(h,"  \"feed_kind\": \"FIXTURE\",");
   NI_W(h,"  \"simulated\": true,");
   NI_W(h,"  \"server_utc\": 1787442034,");
   NI_W(h,"  \"status\": \"LIVE\",");
   NI_W(h,"  \"tz_note\": \"UTC\",");
   NI_W(h,"  \"events\": [");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"eur-sentix-expired\",");
   NI_W(h,"      \"utc\": 1787398834,");
   NI_W(h,"      \"currency\": \"EUR\",");
   NI_W(h,"      \"country\": \"EU\",");
   NI_W(h,"      \"name\": \"Sentix Investor Confidence\",");
   NI_W(h,"      \"impact\": 1,");
   NI_W(h,"      \"actual\": \"-8.2\",");
   NI_W(h,"      \"forecast\": \"-7.0\",");
   NI_W(h,"      \"previous\": \"-9.0\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/eur-sentix\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"usd-ppi-justposted\",");
   NI_W(h,"      \"utc\": 1787441554,");
   NI_W(h,"      \"currency\": \"USD\",");
   NI_W(h,"      \"country\": \"US\",");
   NI_W(h,"      \"name\": \"PPI m/m\",");
   NI_W(h,"      \"impact\": 3,");
   NI_W(h,"      \"actual\": \"0.4%\",");
   NI_W(h,"      \"forecast\": \"0.2%\",");
   NI_W(h,"      \"previous\": \"0.1%\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/usd-ppi\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"usd-fed-rate\",");
   NI_W(h,"      \"utc\": 1787443114,");
   NI_W(h,"      \"currency\": \"USD\",");
   NI_W(h,"      \"country\": \"US\",");
   NI_W(h,"      \"name\": \"Fed Interest Rate Decision\",");
   NI_W(h,"      \"impact\": 3,");
   NI_W(h,"      \"actual\": \"\",");
   NI_W(h,"      \"forecast\": \"5.50%\",");
   NI_W(h,"      \"previous\": \"5.50%\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/usd-fed-rate\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"gbp-cpi\",");
   NI_W(h,"      \"utc\": 1787444914,");
   NI_W(h,"      \"currency\": \"GBP\",");
   NI_W(h,"      \"country\": \"UK\",");
   NI_W(h,"      \"name\": \"CPI y/y\",");
   NI_W(h,"      \"impact\": 3,");
   NI_W(h,"      \"actual\": \"\",");
   NI_W(h,"      \"forecast\": \"2.3%\",");
   NI_W(h,"      \"previous\": \"2.0%\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/gbp-cpi\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"usd-fomc-presser\",");
   NI_W(h,"      \"utc\": 1787446714,");
   NI_W(h,"      \"currency\": \"USD\",");
   NI_W(h,"      \"country\": \"US\",");
   NI_W(h,"      \"name\": \"FOMC Press Conference\",");
   NI_W(h,"      \"impact\": 3,");
   NI_W(h,"      \"actual\": \"\",");
   NI_W(h,"      \"forecast\": \"\",");
   NI_W(h,"      \"previous\": \"\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/usd-fomc-presser\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"eur-ecb-speech\",");
   NI_W(h,"      \"utc\": 1787448154,");
   NI_W(h,"      \"currency\": \"EUR\",");
   NI_W(h,"      \"country\": \"EU\",");
   NI_W(h,"      \"name\": \"ECB President Speech\",");
   NI_W(h,"      \"impact\": 2,");
   NI_W(h,"      \"actual\": \"\",");
   NI_W(h,"      \"forecast\": \"\",");
   NI_W(h,"      \"previous\": \"\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/eur-ecb-speech\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"chf-cpi\",");
   NI_W(h,"      \"utc\": 1787451034,");
   NI_W(h,"      \"currency\": \"CHF\",");
   NI_W(h,"      \"country\": \"CH\",");
   NI_W(h,"      \"name\": \"CPI m/m\",");
   NI_W(h,"      \"impact\": 1,");
   NI_W(h,"      \"actual\": \"\",");
   NI_W(h,"      \"forecast\": \"0.1%\",");
   NI_W(h,"      \"previous\": \"0.0%\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/chf-cpi\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"xau-inventory-context\",");
   NI_W(h,"      \"utc\": 1787454034,");
   NI_W(h,"      \"currency\": \"XAU\",");
   NI_W(h,"      \"country\": \"\",");
   NI_W(h,"      \"name\": \"Gold ETF Flows (weekly)\",");
   NI_W(h,"      \"impact\": 1,");
   NI_W(h,"      \"actual\": \"\",");
   NI_W(h,"      \"forecast\": \"\",");
   NI_W(h,"      \"previous\": \"\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/xau-flows\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"jpy-boj-minutes\",");
   NI_W(h,"      \"utc\": 1787456434,");
   NI_W(h,"      \"currency\": \"JPY\",");
   NI_W(h,"      \"country\": \"JP\",");
   NI_W(h,"      \"name\": \"BoJ Meeting Minutes\",");
   NI_W(h,"      \"impact\": 2,");
   NI_W(h,"      \"actual\": \"\",");
   NI_W(h,"      \"forecast\": \"\",");
   NI_W(h,"      \"previous\": \"\",");
   NI_W(h,"      \"url\": \"\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"cad-employment\",");
   NI_W(h,"      \"utc\": 1787460034,");
   NI_W(h,"      \"currency\": \"CAD\",");
   NI_W(h,"      \"country\": \"CA\",");
   NI_W(h,"      \"name\": \"Employment Change\",");
   NI_W(h,"      \"impact\": 3,");
   NI_W(h,"      \"actual\": \"\",");
   NI_W(h,"      \"forecast\": \"21.0K\",");
   NI_W(h,"      \"previous\": \"14.5K\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/cad-employment\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"aud-retail\",");
   NI_W(h,"      \"utc\": 1787467234,");
   NI_W(h,"      \"currency\": \"AUD\",");
   NI_W(h,"      \"country\": \"AU\",");
   NI_W(h,"      \"name\": \"Retail Sales m/m\",");
   NI_W(h,"      \"impact\": 2,");
   NI_W(h,"      \"actual\": \"\",");
   NI_W(h,"      \"forecast\": \"0.3%\",");
   NI_W(h,"      \"previous\": \"0.1%\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/aud-retail\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"id\": \"nzd-rate\",");
   NI_W(h,"      \"utc\": 1787478634,");
   NI_W(h,"      \"currency\": \"NZD\",");
   NI_W(h,"      \"country\": \"NZ\",");
   NI_W(h,"      \"name\": \"RBNZ Official Cash Rate\",");
   NI_W(h,"      \"impact\": 3,");
   NI_W(h,"      \"actual\": \"\",");
   NI_W(h,"      \"forecast\": \"4.75%\",");
   NI_W(h,"      \"previous\": \"4.75%\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/nzd-rate\"");
   NI_W(h,"    }");
   NI_W(h,"  ],");
   NI_W(h,"  \"headlines\": [");
   NI_W(h,"    {");
   NI_W(h,"      \"utc\": 1787441914,");
   NI_W(h,"      \"currency\": \"USD\",");
   NI_W(h,"      \"title\": \"Dollar strengthens ahead of Fed decision\",");
   NI_W(h,"      \"impact\": 3,");
   NI_W(h,"      \"sentiment\": 0.2,");
   NI_W(h,"      \"source\": \"Fixture Newswire\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/news/usd-1\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"utc\": 1787441494,");
   NI_W(h,"      \"currency\": \"EUR\",");
   NI_W(h,"      \"title\": \"Euro steady as ECB speech awaited\",");
   NI_W(h,"      \"impact\": 2,");
   NI_W(h,"      \"sentiment\": 0,");
   NI_W(h,"      \"source\": \"Fixture Newswire\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/news/eur-1\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"utc\": 1787441134,");
   NI_W(h,"      \"currency\": \"XAU\",");
   NI_W(h,"      \"title\": \"Gold rises on safe-haven demand\",");
   NI_W(h,"      \"impact\": 3,");
   NI_W(h,"      \"sentiment\": 0.4,");
   NI_W(h,"      \"source\": \"Fixture Metals Desk\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/news/xau-1\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"utc\": 1787440714,");
   NI_W(h,"      \"currency\": \"GBP\",");
   NI_W(h,"      \"title\": \"Sterling softens before CPI print\",");
   NI_W(h,"      \"impact\": 3,");
   NI_W(h,"      \"sentiment\": -0.3,");
   NI_W(h,"      \"source\": \"Fixture Newswire\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/news/gbp-1\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"utc\": 1787440414,");
   NI_W(h,"      \"currency\": \"USD\",");
   NI_W(h,"      \"title\": \"Treasury yields tick higher into FOMC\",");
   NI_W(h,"      \"impact\": 2,");
   NI_W(h,"      \"sentiment\": 0.1,");
   NI_W(h,"      \"source\": \"Fixture Rates Desk\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/news/usd-2\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"utc\": 1787439934,");
   NI_W(h,"      \"currency\": \"USD\",");
   NI_W(h,"      \"title\": \"Risk sentiment cautious pre-Fed\",");
   NI_W(h,"      \"impact\": 2,");
   NI_W(h,"      \"sentiment\": -0.1,");
   NI_W(h,"      \"source\": \"Fixture Newswire\",");
   NI_W(h,"      \"url\": \"\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"utc\": 1787439394,");
   NI_W(h,"      \"currency\": \"JPY\",");
   NI_W(h,"      \"title\": \"Yen firms as risk appetite fades\",");
   NI_W(h,"      \"impact\": 2,");
   NI_W(h,"      \"sentiment\": 0.2,");
   NI_W(h,"      \"source\": \"Fixture FX Desk\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/news/jpy-1\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"utc\": 1787437834,");
   NI_W(h,"      \"currency\": \"CAD\",");
   NI_W(h,"      \"title\": \"Loonie eyes jobs data later\",");
   NI_W(h,"      \"impact\": 1,");
   NI_W(h,"      \"sentiment\": null,");
   NI_W(h,"      \"source\": \"Fixture FX Desk\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/news/cad-1\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"utc\": 1787433634,");
   NI_W(h,"      \"currency\": \"AUD\",");
   NI_W(h,"      \"title\": \"Aussie range-bound overnight\",");
   NI_W(h,"      \"impact\": 1,");
   NI_W(h,"      \"sentiment\": 0,");
   NI_W(h,"      \"source\": \"Fixture FX Desk\",");
   NI_W(h,"      \"url\": \"https://example.test/fixture/news/aud-1\"");
   NI_W(h,"    }");
   NI_W(h,"  ],");
   NI_W(h,"  \"heat\": [");
   NI_W(h,"    {");
   NI_W(h,"      \"currency\": \"USD\",");
   NI_W(h,"      \"score\": 67,");
   NI_W(h,"      \"band\": \"HIGH\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"currency\": \"EUR\",");
   NI_W(h,"      \"score\": 13,");
   NI_W(h,"      \"band\": \"LOW\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"currency\": \"GBP\",");
   NI_W(h,"      \"score\": 33,");
   NI_W(h,"      \"band\": \"LOW\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"currency\": \"JPY\",");
   NI_W(h,"      \"score\": 12,");
   NI_W(h,"      \"band\": \"LOW\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"currency\": \"CHF\",");
   NI_W(h,"      \"score\": 3,");
   NI_W(h,"      \"band\": \"LOW\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"currency\": \"CAD\",");
   NI_W(h,"      \"score\": 15,");
   NI_W(h,"      \"band\": \"LOW\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"currency\": \"AUD\",");
   NI_W(h,"      \"score\": 6,");
   NI_W(h,"      \"band\": \"LOW\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"currency\": \"NZD\",");
   NI_W(h,"      \"score\": 14,");
   NI_W(h,"      \"band\": \"LOW\"");
   NI_W(h,"    },");
   NI_W(h,"    {");
   NI_W(h,"      \"currency\": \"XAU\",");
   NI_W(h,"      \"score\": 10,");
   NI_W(h,"      \"band\": \"LOW\"");
   NI_W(h,"    }");
   NI_W(h,"  ],");
   NI_W(h,"  \"next_high_impact\": {");
   NI_W(h,"    \"id\": \"usd-fed-rate\",");
   NI_W(h,"    \"currency\": \"USD\",");
   NI_W(h,"    \"name\": \"Fed Interest Rate Decision\",");
   NI_W(h,"    \"utc\": 1787443114");
   NI_W(h,"  }");
   NI_W(h,"}");
   FileClose(h);
   Print("NI: embedded fixture written to MQL4\\Files\\", fname,
         " (file was missing; existing files are never overwritten)");
   return true;
}

// Ensure a fixture is present WITHOUT overriding an existing one.
// - if the file exists: do nothing (respect the user's own copy).
// - if absent: write the embedded copy once.
void NI_EnsureFixture(string fname)
{
   if(NI_FixtureExists(fname))
   {
      Print("NI: fixture already present, using existing file (not overwritten): ", fname);
      return;
   }
   Print("NI: fixture missing -> writing embedded copy once: ", fname);
   NI_WriteEmbeddedFixture(fname);
}
//+------------------------------------------------------------------+
//| 50_strength.mqh - LIGHTWEIGHT INDEPENDENT STRENGTH CONTEXT        |
//|                                                                   |
//| Purpose: provide currency-strength CONTEXT beside a news event    |
//| (e.g. "USD 86.8 up") for the future News Impact Monitor. It is:   |
//|                                                                   |
//|   * INDEPENDENT - does not call any FX PowerMap function, does    |
//|     not read PowerMap objects/globals, does not touch PowerMap.   |
//|   * METHODOLOGY-COMPATIBLE - uses the SAME concepts as PowerMap   |
//|     where they overlap, so results can later be compared:         |
//|       - same 9-currency universe (USD EUR GBP JPY CHF CAD AUD     |
//|         NZD + XAU first-class),                                   |
//|       - strength derived from each currency's average performance |
//|         across the pairs it appears in (basket-average concept,   |
//|         same as PowerMap's basket idea, NOT the full 28-pair      |
//|         sigma-normalised institutional engine),                   |
//|       - DIRECTION defined the same way: sign of recent change     |
//|         (up / flat / down),                                       |
//|       - broker SYMBOL handling by alphanumeric-core matching so   |
//|         suffixes/prefixes (EURUSDm, EURUSD.a, .pro) resolve,      |
//|       - 0..100 display scale, same interpretation bands.          |
//|                                                                   |
//| It does NOT:                                                      |
//|   * clone the 28-pair + gold institutional formula,               |
//|   * convert strength into BUY/SELL,                               |
//|   * alter NEWS HEAT,                                              |
//|   * depend on the PowerMap UI.                                    |
//|                                                                   |
//| DOCUMENTED FORMULA (so it can be compared to PowerMap later):     |
//|   For each of the 7 fiat majors we look at the 8 pairs formed     |
//|   against the other majors. For a pair BASE/QUOTE we take the     |
//|   percentage change of close over LOOKBACK bars:                  |
//|       chg = (Close[0]-Close[LB]) / Close[LB]                      |
//|   A rising pair adds +chg to BASE strength and -chg to QUOTE.     |
//|   Each currency's raw score = average of its signed contributions |
//|   across the pairs it appears in. Raw scores are squashed to      |
//|   0..100 with a bounded linear map around 0 (disp = 50 + k*raw,   |
//|   clamped), matching PowerMap's "50 = neutral" reading. XAU uses  |
//|   its own single-symbol read (XAUUSD % change) mapped the same    |
//|   way, so gold stays first-class without importing PowerMap's     |
//|   7-component gold model. Direction = sign of the same change,    |
//|   with a small dead-zone for "flat".                              |
//|                                                                   |
//| This is a LIGHTWEIGHT approximation by design. If a later phase    |
//| needs the full institutional numbers, this module can be replaced |
//| wholesale WITHOUT changing the News Intelligence data contract.    |
//+------------------------------------------------------------------+

// tuneable, documented constants
#define NI_STR_LOOKBACK 24        // bars of change used for the read
#define NI_STR_TF       PERIOD_H1 // timeframe for the context read
#define NI_STR_K        900.0     // scale factor raw->display around 50
#define NI_STR_DEADZONE 0.0002    // |chg| below this => flat direction

// the 7 fiat majors used to build baskets (XAU handled separately)
string NI_FIAT[7];
void NI_InitFiat()
{
   NI_FIAT[0]="USD"; NI_FIAT[1]="EUR"; NI_FIAT[2]="GBP"; NI_FIAT[3]="JPY";
   NI_FIAT[4]="CHF"; NI_FIAT[5]="CAD"; NI_FIAT[6]="AUD";
   // NZD is in the universe; to keep the lightweight basket symmetric we treat
   // the 7 above as the "spanning" set and still score NZD via its pairs below.
}

// --- broker symbol resolver by alphanumeric core (same principle as PowerMap) ---
string NI_CoreOf(string sym)
{
   string s=NI_Upper(sym);
   string core="";
   for(int i=0;i<StringLen(s);i++)
   {
      int c=StringGetCharacter(s,i);
      if((c>='A'&&c<='Z')||(c>='0'&&c<='9')) core+=CharToString((uchar)c);
   }
   return core;
}

// find a broker symbol whose core matches want (e.g. "EURUSD"); "" if none
string NI_FindSymbol(string want)
{
   string wantCore=NI_CoreOf(want);
   int total=SymbolsTotal(false);
   // pass 1: exact core
   for(int i=0;i<total;i++)
   {
      string nm=SymbolName(i,false);
      if(NI_CoreOf(nm)==wantCore) return nm;
   }
   // pass 2: core contained (handles prefixes/suffixes beyond punctuation)
   for(int i2=0;i2<total;i2++)
   {
      string nm2=SymbolName(i2,false);
      if(StringFind(NI_CoreOf(nm2), wantCore)>=0) return nm2;
   }
   return "";
}

// percentage change of close over lookback for a resolved pair; returns
// hasData=false if the symbol/price is unavailable (never fabricates).
double NI_PairChange(string want, bool &hasData)
{
   hasData=false;
   string sym=NI_FindSymbol(want);
   if(sym=="") return 0.0;
   double c0=iClose(sym, NI_STR_TF, 0);
   double cL=iClose(sym, NI_STR_TF, NI_STR_LOOKBACK);
   if(c0<=0.0 || cL<=0.0) return 0.0;
   hasData=true;
   return (c0-cL)/cL;
}

// ---- BROKER-AWARE GOLD SYMBOL RESOLVER (XAU live context only) --------------
// Resolves the broker's tradable gold symbol. Internal identifier stays XAU;
// this only maps XAU -> the broker's actual symbol name. Resolution order:
//   1. GOLD              2. XAUUSD           3. XAUUSDm
//   4. XAUUSD.a          5. XAUUSD.pro       6. other suffix/prefix variants
// Each candidate is verified to EXIST in the symbol list before use; the final
// price validity is confirmed by NI_PairChange (needs live bars). Returns the
// resolved broker symbol name, or "" if none is available. Never fabricates.
bool NI_SymbolExists(string sym)
{
   if(sym=="") return false;
   int total=SymbolsTotal(false);
   for(int i=0;i<total;i++)
      if(SymbolName(i,false)==sym) return true;
   return false;
}

string NI_FindGoldSymbol()
{
   // explicit ordered candidates first (exact broker names)
   string cand[5];
   cand[0]="GOLD";
   cand[1]="XAUUSD";
   cand[2]="XAUUSDm";
   cand[3]="XAUUSD.a";
   cand[4]="XAUUSD.pro";
   for(int i=0;i<5;i++)
      if(NI_SymbolExists(cand[i])) return cand[i];

   // fallback: scan every broker symbol for a gold core (XAUUSD or GOLD),
   // covering any other prefix/suffix variation (e.g. mXAUUSD, XAUUSD_i, GOLD.r)
   int total=SymbolsTotal(false);
   for(int s=0;s<total;s++)
   {
      string nm=SymbolName(s,false);
      string core=NI_CoreOf(nm);   // alphanumeric-only upper core
      if(StringFind(core,"XAUUSD")>=0) return nm;
   }
   for(int s2=0;s2<total;s2++)
   {
      string nm2=SymbolName(s2,false);
      string core2=NI_CoreOf(nm2);
      // match GOLD but avoid false hits like "GOLDMANSACHS"-style CFDs by
      // requiring the core to be exactly GOLD or start with GOLD + short tail
      if(core2=="GOLD") return nm2;
      if(StringFind(core2,"GOLD")==0 && StringLen(core2)<=6) return nm2;
   }
   return "";
}

// % change for the resolved gold symbol; hasData=false if unavailable.
double NI_GoldChange(string &resolvedSym, bool &hasData)
{
   hasData=false;
   resolvedSym=NI_FindGoldSymbol();
   if(resolvedSym=="") return 0.0;
   double c0=iClose(resolvedSym, NI_STR_TF, 0);
   double cL=iClose(resolvedSym, NI_STR_TF, NI_STR_LOOKBACK);
   if(c0<=0.0 || cL<=0.0) return 0.0;   // symbol exists but no live bars yet
   hasData=true;
   return (c0-cL)/cL;
}

// map a raw signed score to 0..100 around 50 (documented linear+clamp)
double NI_ToDisplay(double raw)
{
   double d = 50.0 + NI_STR_K*raw;
   if(d<0.0) d=0.0; if(d>100.0) d=100.0;
   return d;
}

// direction from a signed change with a dead-zone
int NI_DirFromChange(double chg)
{
   if(chg >  NI_STR_DEADZONE) return +1;
   if(chg < -NI_STR_DEADZONE) return -1;
   return 0;
}

// Build the lightweight strength context for all 9 assets.
// Fills g_strength[] (0..100, or -1 if no data) and g_strengthDir[] (+1/0/-1).
void NI_ComputeStrengthContext()
{
   ArrayResize(g_strength, NI_NCCY);
   ArrayResize(g_strengthDir, NI_NCCY);
   for(int i=0;i<NI_NCCY;i++){ g_strength[i]=-1; g_strengthDir[i]=0; }

   // accumulate signed contributions per currency across the majors grid.
   // Initialise all three at declaration (fixed size 9) so the compiler sees
   // them definitely-assigned before the read loops below (clears the
   // "possible use of uninitialized variable" warnings).
   double sum[9];
   int    cnt[9];
   double dirSum[9];
   ArrayInitialize(sum,    0.0);
   ArrayInitialize(cnt,    0);
   ArrayInitialize(dirSum, 0.0);

   // fiat vs fiat grid (unique unordered pairs among the 8 fiat: indices 0..7)
   for(int bi=0; bi<8; bi++)
   {
      for(int qi=bi+1; qi<8; qi++)
      {
         string bcc=NI_CCY[bi];   // base candidate
         string qcc=NI_CCY[qi];   // quote candidate
         if(bcc=="XAU"||qcc=="XAU") continue;   // XAU handled separately
         bool hd=false;
         double chg=NI_PairChange(bcc+qcc, hd);
         if(!hd)
         {
            // try reversed orientation (QUOTE/BASE); invert sign if found
            double chg2=NI_PairChange(qcc+bcc, hd);
            if(hd) chg=-chg2;
         }
         if(!hd) continue;   // no data for this pair -> skip, never fabricate
         // rising BASE/QUOTE strengthens base, weakens quote
         sum[bi]+=chg; cnt[bi]++; dirSum[bi]+=chg;
         sum[qi]-=chg; cnt[qi]++; dirSum[qi]-=chg;
      }
   }

   for(int c=0;c<8;c++)
   {
      if(cnt[c]>0)
      {
         double raw=sum[c]/cnt[c];
         g_strength[c]=NI_ToDisplay(raw);
         g_strengthDir[c]=NI_DirFromChange(dirSum[c]);
      }
   }

   // XAU: single-symbol read via broker-aware gold resolver (GOLD/XAUUSD/...).
   // Internal identifier remains XAU; only the broker symbol name is resolved.
   bool hg=false;
   double gch=NI_GoldChange(g_goldSymbol, hg);
   if(hg)
   {
      g_strength[8]=NI_ToDisplay(gch);
      g_strengthDir[8]=NI_DirFromChange(gch);
   }
}

// convenience: strength text like "86.8 up" or "n/a"
string NI_StrengthText(string ccy)
{
   int idx=NI_CcyIndex(ccy);
   if(idx<0 || g_strength[idx]<0) return "n/a";
   string arrow = g_strengthDir[idx]>0 ? "up" : (g_strengthDir[idx]<0 ? "down" : "flat");
   return StringFormat("%.1f %s", g_strength[idx], arrow);
}
//+------------------------------------------------------------------+
//| 70_ui_theme.mqh - Stage 3 UI theme + NI_ object helpers           |
//|                                                                   |
//| Standalone News Intelligence presentation. Independent of FX      |
//| PowerMap: its own palette, its own NI_-prefixed objects. Consumes |
//| the frozen engine; changes no engine logic. No WebRequest.        |
//|                                                                   |
//| ALL chart objects created here carry the NI_ prefix. PowerMap     |
//| objects/globals/functions are never touched.                      |
//+------------------------------------------------------------------+

// ---- Stage 3 UI inputs (additive; defaults keep behaviour unchanged) -------
input string NI_UI_Sep       = "===== NEWS INTELLIGENCE UI (Stage 3) =====";
input bool   NI_ShowPanel    = true;   // draw the standalone panel
input int    NI_ViewMode     = 0;      // 0=COMPACT (default) 1=FULL 2=AUTO
input int    NI_ThemeMode    = 0;      // 0=DARK 1=LIGHT
input int    NI_PanelX       = 8;      // panel left (px from chart left)
input int    NI_PanelY       = 20;     // panel top  (px from chart top)
input int    NI_RefreshSec   = 1;      // dynamic refresh cadence (countdown/status)
input bool   NI_DragEnable   = true;   // Stage 4: header drag-to-move (ON by default)
input int    NI_FullListDef  = 0;      // Stage 4: FULL list region 0=CAL 1=NEWS (default CAL)

// ---- object prefix (every Stage 3 object begins with this) -----------------
#define NIP "NI_"

// ---- view + tab enums ------------------------------------------------------
#define NIV_COMPACT 0
#define NIV_FULL    1
#define NIV_AUTO    2

#define NITAB_HEAT   0
#define NITAB_CAL    1
#define NITAB_NEWS   2
#define NITAB_IMPACT 3
#define NITAB_CTX    4
#define NITAB_BATTLE 5
#define NITAB_COUNT  6

// ---- UI runtime state (Stage-3-local; not engine state) --------------------
int    g_ni_view    = NIV_COMPACT;  // resolved current view
int    g_ni_theme   = 0;            // 0 dark 1 light
int    g_ni_tab     = NITAB_HEAT;   // active tab (compact)
int    g_ni_pageCal = 0;            // paging offsets (display only)
int    g_ni_pageNews= 0;
int    g_ni_pageImp = 0;
bool   g_ni_min     = false;        // minimised
bool   g_ni_built   = false;
int    g_ni_battleA = 0;            // battle currency A index (NI_CCY)
int    g_ni_battleB = 3;            // battle currency B index

// ---- Stage 4 additions: filters, drag, full-view content, restore memory ---
// filter state (DISPLAY predicates only; never mutate engine stores)
int    g_ni_fCcy    = -1;           // -1 = ALL, else NI_CCY index
int    g_ni_fImpact = 0;            // 0=ALL 3=HIGH 2=MED 1=LOW
int    g_ni_fTime   = 0;            // 0=ALL 1=UPCOMING 2=TODAY 3=PAST
// full-view list region choice (default CAL; NEWS selectable)
int    g_ni_fullList= NITAB_CAL;    // NITAB_CAL or NITAB_NEWS
// view override: -1 = follow NI_ViewMode input/AUTO; 0/1 = user forced COMPACT/FULL
int    g_ni_viewOverride = -1;
// drag state (header-only dragging)
bool   g_ni_dragging= false;
int    g_ni_dragDX  = 0;            // cursor-to-panel offset captured on grab
int    g_ni_dragDY  = 0;
// restore memory (minimize -> restore returns to exact prior view/tab)
int    g_ni_savedView = NIV_COMPACT;
int    g_ni_savedTab  = NITAB_HEAT;

// runtime-mutable panel position (inputs NI_PanelX/Y are read-only; drag needs
// mutable values). Initialised from the inputs in OnInit.
int    NI_PanelX_rt = 8;
int    NI_PanelY_rt = 20;

// time-filter buckets
#define NIF_TIME_ALL      0
#define NIF_TIME_UPCOMING 1
#define NIF_TIME_TODAY    2
#define NIF_TIME_PAST     3

// ---- theme palette (independent of PowerMap; NI-local) ---------------------
// colours are BGR (MT4). Two palettes; heat band colours are theme-independent.
color NI_C_BG, NI_C_PANEL, NI_C_INNER, NI_C_BORDER, NI_C_TXT, NI_C_DIM,
      NI_C_HDR, NI_C_BTN, NI_C_BTNTX, NI_C_ACCENT, NI_C_BTNSEL, NI_C_DIVIDER;
// heat / state colours (fixed across themes for legibility)
color NI_C_HIGH   = 0x3B47E5;  // red   (BGR of #E5473B)
color NI_C_MED    = 0x2B9CF3;  // orange
color NI_C_LOW    = 0x3ABF5B;  // green
color NI_C_LIVE   = 0x3ABF5B;  // green dot
color NI_C_STALE  = 0x2BC9E2;  // amber
color NI_C_OFF    = 0x3B47E5;  // red


void NI_ApplyTheme(int mode)
{
   g_ni_theme = mode;
   if(mode==1)  // LIGHT
   {
      NI_C_BG      = 0xFFFFFF;
      NI_C_PANEL   = 0xFFFFFF;
      NI_C_INNER   = 0xF2F4F7;
      NI_C_BORDER  = 0xD8DEE6;
      NI_C_TXT     = 0x34261A;   // dark navy-ish (legible on white)
      NI_C_DIM     = 0x8A7A6A;
      NI_C_HDR     = 0x6D4A2F;
      NI_C_BTN     = 0xE2DAD2;   // light grey button
      NI_C_BTNTX   = 0x34261A;   // dark text on light button (legible)
      NI_C_ACCENT  = 0x6D4A2F;
      NI_C_BTNSEL  = 0x9C6D2F;   // selected filter/toggle (blue-ish accent)
      NI_C_DIVIDER = 0xE0E4E8;
   }
   else         // DARK (default)
   {
      NI_C_BG      = 0x16120E;
      NI_C_PANEL   = 0x201A14;
      NI_C_INNER   = 0x2A211A;
      NI_C_BORDER  = 0x332B22;
      NI_C_TXT     = 0xE8E8E8;
      NI_C_DIM     = 0x99908A;
      NI_C_HDR     = 0xE0B13A;
      NI_C_BTN     = 0x2C2620;   // dark button
      NI_C_BTNTX   = 0xE8E8E8;   // light text on dark button (legible)
      NI_C_ACCENT  = 0xE0B13A;
      NI_C_BTNSEL  = 0xE0B13A;   // selected filter/toggle (gold accent)
      NI_C_DIVIDER = 0x30281F;
   }
}

// band -> colour
color NI_BandColor(string band)
{
   if(band=="HIGH")   return NI_C_HIGH;
   if(band=="MEDIUM") return NI_C_MED;
   return NI_C_LOW;
}

// ---- low-level object helpers (all NI_-prefixed) ---------------------------
void NI_Rect(string id, int x, int y, int w, int h, color bg, color border)
{
   string nm = NIP+id;
   if(ObjectFind(0,nm)<0)
      ObjectCreate(0,nm,OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,nm,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,nm,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,nm,OBJPROP_XSIZE,w);
   ObjectSetInteger(0,nm,OBJPROP_YSIZE,h);
   ObjectSetInteger(0,nm,OBJPROP_BGCOLOR,bg);
   ObjectSetInteger(0,nm,OBJPROP_BORDER_TYPE,BORDER_FLAT);
   ObjectSetInteger(0,nm,OBJPROP_COLOR,border);
   ObjectSetInteger(0,nm,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,nm,OBJPROP_BACK,false);
   ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
}

void NI_Label(string id, int x, int y, string text, color col, int fontsize, string font)
{
   string nm = NIP+id;
   if(ObjectFind(0,nm)<0)
      ObjectCreate(0,nm,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,nm,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,nm,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,nm,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,nm,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);
   ObjectSetString(0,nm,OBJPROP_TEXT,text);
   ObjectSetInteger(0,nm,OBJPROP_COLOR,col);
   ObjectSetInteger(0,nm,OBJPROP_FONTSIZE,fontsize);
   ObjectSetString(0,nm,OBJPROP_FONT,font);
   ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
}

// right-anchored label (for values / countdowns)
void NI_LabelR(string id, int x, int y, string text, color col, int fontsize, string font)
{
   string nm = NIP+id;
   if(ObjectFind(0,nm)<0)
      ObjectCreate(0,nm,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,nm,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,nm,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,nm,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,nm,OBJPROP_ANCHOR,ANCHOR_RIGHT_UPPER);
   ObjectSetString(0,nm,OBJPROP_TEXT,text);
   ObjectSetInteger(0,nm,OBJPROP_COLOR,col);
   ObjectSetInteger(0,nm,OBJPROP_FONTSIZE,fontsize);
   ObjectSetString(0,nm,OBJPROP_FONT,font);
   ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
}

// clickable button (NI_-prefixed); tag returned via object name in OnChartEvent
void NI_Button(string id, int x, int y, int w, int h, string text, color bg, color txt)
{
   string nm = NIP+id;
   if(ObjectFind(0,nm)<0)
      ObjectCreate(0,nm,OBJ_BUTTON,0,0,0);
   ObjectSetInteger(0,nm,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,nm,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,nm,OBJPROP_XSIZE,w);
   ObjectSetInteger(0,nm,OBJPROP_YSIZE,h);
   ObjectSetString(0,nm,OBJPROP_TEXT,text);
   ObjectSetInteger(0,nm,OBJPROP_BGCOLOR,bg);
   ObjectSetInteger(0,nm,OBJPROP_COLOR,txt);
   ObjectSetInteger(0,nm,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,nm,OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,nm,OBJPROP_STATE,false);
   ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
}

// selected/unselected filter or toggle button: picks colours by 'on' state
void NI_ButtonSel(string id, int x, int y, int w, int h, string text, bool on)
{
   color bg = on ? NI_C_BTNSEL : NI_C_BTN;
   color tx = on ? NI_C_PANEL  : NI_C_BTNTX;
   NI_Button(id, x, y, w, h, text, bg, tx);
}

// delete every NI_-prefixed object (Stage 3 owns only NI_ objects)
void NI_DeleteAllNI()
{
   int total=ObjectsTotal(0,-1,-1);
   for(int i=total-1;i>=0;i--)
   {
      string nm=ObjectName(0,i);
      if(StringFind(nm,NIP)==0)
         ObjectDelete(0,nm);
   }
}
//+------------------------------------------------------------------+
//| 80_ui_layout.mqh - Stage 3 layout solver (compact/full)          |
//|                                                                   |
//| Computes panel + region rectangles from the live chart client     |
//| size. Compact (default) fits ~1362x530 and smaller; full expands  |
//| when space allows. Pure geometry - reads nothing from the engine  |
//| except via the render layer. No objects created here.             |
//+------------------------------------------------------------------+

// resolved layout rectangles (Stage-3-local globals)
int LYP_x, LYP_y, LYP_w, LYP_h;          // whole panel
int LY_hdrY, LY_hdrH;                     // header row
int LY_nextY, LY_nextH;                   // next-high strip
int LY_tabY, LY_tabH;                     // tab bar
int LY_fltY, LY_fltH;                     // Stage 4: filter row
int LY_bodyY, LY_bodyH;                   // body area (tab content)
int LY_footY, LY_footH;                   // footer
int LY_rowH;                              // generic row height in body
int LY_rowsPerPage;                       // list rows that fit in body
double g_ni_sf = 1.0;                     // width-driven scale factor

// Stage 4 FULL layout: two columns (heat | list) + impact strip
int LYF_colHeatX, LYF_colHeatW;           // left column (heat)
int LYF_colListX, LYF_colListW;           // right column (cal/news list)
int LYF_impY, LYF_impH;                    // impact/next strip region (full)

// scale a base pixel value
int NI_S(double v){ int r=(int)MathRound(v*g_ni_sf); return (r<1?1:r); }

// decide effective view given input + live chart size
int NI_DecideView(int cw, int ch)
{
   // manual toggle wins: once the user clicks COMP/FULL, honour their choice
   if(g_ni_viewOverride==NIV_COMPACT) return NIV_COMPACT;
   if(g_ni_viewOverride==NIV_FULL)    return NIV_FULL;
   // otherwise follow the input / AUTO sizing
   if(NI_ViewMode==NIV_COMPACT) return NIV_COMPACT;
   if(NI_ViewMode==NIV_FULL)    return NIV_FULL;
   // AUTO: full only when there is real room
   if(cw>=900 && ch>=700) return NIV_FULL;
   return NIV_COMPACT;
}

// main solver: fills LY_* from chart width/height and current view/min state
void NI_SolveLayout()
{
   int cw=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS,0);
   int ch=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   if(cw<=0) cw=1362;
   if(ch<=0) ch=530;

   g_ni_view = NI_DecideView(cw,ch);

   // width-driven scale so text never bloats past the panel at small widths
   double baseW = (g_ni_view==NIV_FULL) ? 520.0 : 330.0;
   g_ni_sf = 1.0;
   if(cw < 1200) g_ni_sf = 0.92;
   if(cw < 1024) g_ni_sf = 0.85;
   if(cw < 900)  g_ni_sf = 0.80;

   LYP_w = NI_S(baseW);
   // safety: never let the panel exceed the chart width (forced FULL on a narrow
   // window). Leave an 8px right margin; keep a sane minimum.
   int maxW = cw - NI_PanelX_rt - NI_S(8);
   if(maxW < NI_S(300)) maxW = NI_S(300);
   if(LYP_w > maxW) LYP_w = maxW;
   LYP_x = NI_PanelX_rt;
   LYP_y = NI_PanelY_rt;

   // vertical bands
   LY_hdrH  = NI_S(26);
   LY_nextH = NI_S(24);
   LY_tabH  = NI_S(22);
   LY_fltH  = NI_S(20);   // Stage 4 filter row
   LY_footH = NI_S(18);

   // minimised: only header shows
   if(g_ni_min)
   {
      LYP_h   = LY_hdrH;
      LY_hdrY = LYP_y;
      // collapse the rest
      LY_nextY=LY_tabY=LY_fltY=LY_bodyY=LY_footY=LYP_y+LY_hdrH;
      LY_nextH=LY_tabH=LY_fltH=LY_bodyH=LY_footH=0;
      return;
   }

   // full panel height: cap to available client height minus a small margin
   int wantH = (g_ni_view==NIV_FULL) ? NI_S(560) : NI_S(440);
   int maxH  = ch - LYP_y - NI_S(8);
   if(maxH < NI_S(240)) maxH = NI_S(240);
   LYP_h = (wantH>maxH ? maxH : wantH);

   int y = LYP_y;
   LY_hdrY  = y; y += LY_hdrH;
   LY_nextY = y; y += LY_nextH;
   LY_tabY  = y; y += LY_tabH;
   LY_fltY  = y; y += LY_fltH;           // filter row under the tab bar
   // footer pinned to bottom
   LY_footY = LYP_y + LYP_h - LY_footH;
   LY_bodyY = y;
   LY_bodyH = LY_footY - LY_bodyY - NI_S(2);
   if(LY_bodyH < NI_S(40)) LY_bodyH = NI_S(40);

   LY_rowH = NI_S(20);
   LY_rowsPerPage = LY_bodyH / LY_rowH;
   if(LY_rowsPerPage < 1) LY_rowsPerPage = 1;

   // Stage 4 FULL geometry: split body into heat (left) + list (right),
   // with an impact/next strip across the bottom of the body.
   if(g_ni_view==NIV_FULL)
   {
      int gap = NI_S(6);
      int half = (LYP_w - NI_S(2)*2 - gap)/2;
      LYF_colHeatX = LYP_x + NI_S(2);
      LYF_colHeatW = half;
      LYF_colListX = LYF_colHeatX + half + gap;
      LYF_colListW = half;
      // impact strip occupies the lower third of the body
      LYF_impH = LY_bodyH/3;
      if(LYF_impH < NI_S(60)) LYF_impH = NI_S(60);
      LYF_impY = LY_footY - LYF_impH - NI_S(2);
   }
}

// clamp a page offset so it always lands on a valid page
int NI_ClampPage(int page, int itemCount, int perPage)
{
   if(perPage<1) perPage=1;
   int maxPage = (itemCount<=0) ? 0 : (itemCount-1)/perPage;
   if(page<0) page=0;
   if(page>maxPage) page=maxPage;
   return page;
}

int NI_PageCount(int itemCount, int perPage)
{
   if(perPage<1) perPage=1;
   if(itemCount<=0) return 1;
   return (itemCount-1)/perPage + 1;
}

// ---- Stage 4 filter predicates (DISPLAY ONLY; never mutate stores) ---------
// currency filter: -1 = ALL, else must match NI_CCY[g_ni_fCcy]
bool NI_FilterCcy(string ccy)
{
   if(g_ni_fCcy<0) return true;
   return (ccy==NI_CCY[g_ni_fCcy]);
}
// impact filter: 0 = ALL, else must equal
bool NI_FilterImpact(int impact)
{
   if(g_ni_fImpact==0) return true;
   return (impact==g_ni_fImpact);
}
// time filter over an event utc, using engine state + server_utc.
// ALL / UPCOMING (utc>server_utc) / TODAY (same broker day) / PAST (utc<=server_utc)
bool NI_FilterTime(long utc)
{
   if(g_ni_fTime==NIF_TIME_ALL) return true;
   if(g_ni_fTime==NIF_TIME_UPCOMING) return (utc >  g_server_utc);
   if(g_ni_fTime==NIF_TIME_PAST)     return (utc <= g_server_utc);
   // TODAY: same calendar day as server_utc in the display frame
   if(g_ni_fTime==NIF_TIME_TODAY)
   {
      long a = NI_ToDisplayFrame(utc);
      long b = NI_ToDisplayFrame(g_server_utc);
      return ( (a/86400) == (b/86400) );
   }
   return true;
}
// combined event predicate
bool NI_EventPasses(int i)
{
   return NI_FilterCcy(ev_currency[i]) && NI_FilterImpact(ev_impact[i]) && NI_FilterTime(ev_utc[i]);
}
// combined headline predicate (headlines have no scheduled time-bucket beyond utc;
// time filter treats them as PAST-or-recent, so UPCOMING hides all headlines)
bool NI_HeadlinePasses(int i)
{
   if(!NI_FilterCcy(hl_currency[i])) return false;
   if(!NI_FilterImpact(hl_impact[i])) return false;
   if(g_ni_fTime==NIF_TIME_UPCOMING) return false;   // headlines are published, not upcoming
   return true;
}
//+------------------------------------------------------------------+
//| 85_ui_render.mqh - Stage 3 render layer                          |
//|                                                                   |
//| Builds the standalone News Intelligence panel by READING the      |
//| frozen engine's accessors/stores. Never re-parses JSON, never     |
//| recomputes heat, never re-resolves gold. Pure consumer.           |
//|                                                                   |
//| Consumes: g_status, NI_ConnStateText, NI_IsGenuineLiveData,       |
//|   g_feed_kind/g_simulated/g_feedSimulated, NI_ResolveNextHigh,    |
//|   NI_CountdownText, NI_EventState, ev_* store, hl_* store,        |
//|   NI_HeatScore/NI_HeatBand, NI_StrengthText, g_goldSymbol,        |
//|   NI_ToDisplayFrame, NI_CCY[].                                    |
//+------------------------------------------------------------------+

string NI_TabLabel(int t)
{
   if(t==NITAB_HEAT)   return "HEAT";
   if(t==NITAB_CAL)    return "CAL";
   if(t==NITAB_NEWS)   return "NEWS";
   if(t==NITAB_IMPACT) return "IMPACT";
   if(t==NITAB_CTX)    return "CTX";
   return "BATTLE";
}

// ---- Stage 4: filtered index arrays (display-only views over the stores) ----
int g_ni_evIdx[];   // event indices passing the current filter
int g_ni_evN=0;
int g_ni_hlIdx[];   // headline indices passing the current filter
int g_ni_hlN=0;

void NI_BuildFilteredEvents()
{
   ArrayResize(g_ni_evIdx, g_nEvents>0?g_nEvents:1);
   g_ni_evN=0;
   for(int i=0;i<g_nEvents;i++)
      if(NI_EventPasses(i)){ g_ni_evIdx[g_ni_evN]=i; g_ni_evN++; }
}
void NI_BuildFilteredHeadlines()
{
   ArrayResize(g_ni_hlIdx, g_nHeadlines>0?g_nHeadlines:1);
   g_ni_hlN=0;
   for(int i=0;i<g_nHeadlines;i++)
      if(NI_HeadlinePasses(i)){ g_ni_hlIdx[g_ni_hlN]=i; g_ni_hlN++; }
}

// short label for the currency filter button
string NI_CcyFilterLabel()
{
   if(g_ni_fCcy<0) return "CCY:ALL";
   return "CCY:"+NI_CCY[g_ni_fCcy];
}
string NI_ImpactFilterLabel()
{
   if(g_ni_fImpact==NI_IMP_HIGH) return "IMP:HIGH";
   if(g_ni_fImpact==NI_IMP_MED)  return "IMP:MED";
   if(g_ni_fImpact==NI_IMP_LOW)  return "IMP:LOW";
   return "IMP:ALL";
}
string NI_TimeFilterLabel()
{
   if(g_ni_fTime==NIF_TIME_UPCOMING) return "TIME:UPC";
   if(g_ni_fTime==NIF_TIME_TODAY)    return "TIME:TODAY";
   if(g_ni_fTime==NIF_TIME_PAST)     return "TIME:PAST";
   return "TIME:ALL";
}

// draw the filter row. Compact = ccy + impact; Full = ccy + impact + time.
// Only meaningful for list tabs (CAL/NEWS/IMPACT); still drawn for consistency.
void NI_DrawFilterRow()
{
   NI_Rect("fltbar", LYP_x, LY_fltY, LYP_w, LY_fltH, NI_C_INNER, NI_C_BORDER);
   int bx=LYP_x+NI_S(4);
   int bh=LY_fltH-NI_S(4);
   int by=LY_fltY+NI_S(2);
   int bwC=NI_S(66), bwI=NI_S(60), bwT=NI_S(70);
   NI_ButtonSel("flt_ccy", bx, by, bwC, bh, NI_CcyFilterLabel(), g_ni_fCcy>=0);
   bx+=bwC+NI_S(3);
   NI_ButtonSel("flt_imp", bx, by, bwI, bh, NI_ImpactFilterLabel(), g_ni_fImpact!=0);
   bx+=bwI+NI_S(3);
   if(g_ni_view==NIV_FULL)
   {
      NI_ButtonSel("flt_time", bx, by, bwT, bh, NI_TimeFilterLabel(), g_ni_fTime!=0);
      bx+=bwT+NI_S(3);
   }
   else
   {
      // ensure the full-only time button is not left orphaned in compact
      if(ObjectFind(0,NIP+"flt_time")>=0) ObjectDelete(0,NIP+"flt_time");
   }
   // clear-all filters button (right-aligned)
   NI_Button("flt_clear", LYP_x+LYP_w-NI_S(50), by, NI_S(46), bh, "CLEAR", NI_C_BTN, NI_C_BTNTX);
}

string NI_ImpactWord(int imp)
{
   if(imp==NI_IMP_HIGH) return "HIGH";
   if(imp==NI_IMP_MED)  return "MED";
   if(imp==NI_IMP_LOW)  return "LOW";
   return "-";
}
color NI_ImpactColor(int imp)
{
   if(imp==NI_IMP_HIGH) return NI_C_HIGH;
   if(imp==NI_IMP_MED)  return NI_C_MED;
   if(imp==NI_IMP_LOW)  return NI_C_LOW;
   return NI_C_DIM;
}

// format a UTC epoch to HH:MM in the configured display frame
string NI_HhMm(long utc)
{
   long disp = NI_ToDisplayFrame(utc);
   datetime dt = (datetime)disp;
   MqlDateTime mdt;
   TimeToStruct(dt, mdt);
   return StringFormat("%02d:%02d", mdt.hour, mdt.min);
}

// contextual phrase from strength direction x heat band (NO buy/sell)
string NI_ContextLabel(string ccy)
{
   int idx = NI_CcyIndex(ccy);
   int dir = (idx>=0 ? g_strengthDir[idx] : 0);
   string band = NI_HeatBand(ccy);
   bool strong = (dir>0);
   bool highNews = (band=="HIGH");
   // four approved phrases; MED treated with LOW side of the news axis for wording
   if(strong && highNews)  return "Strong + High News Activity";
   if(strong && !highNews) return "Strong + Low News Activity";
   if(!strong && highNews) return "Weak + High News Activity";
   return "Weak + Low News Activity";
}

//------------------------------------------------------------------
// HEADER (Stage 4: non-overlapping status + button cluster, drag hint)
//------------------------------------------------------------------
void NI_DrawHeader()
{
   NI_Rect("bg", LYP_x, LYP_y, LYP_w, LYP_h, NI_C_PANEL, NI_C_BORDER);
   NI_Rect("hdr", LYP_x, LY_hdrY, LYP_w, LY_hdrH, NI_C_INNER, NI_C_BORDER);
   // title (drag handle) - shrink to fit so it never runs under the buttons
   NI_Label("hdr_title", LYP_x+NI_S(8), LY_hdrY+NI_S(6),
            "$CHbabastevo NEWS INTELLIGENCE", NI_C_HDR, NI_S(9), "Arial Bold");

   // right-aligned button cluster: [theme][view][min][close]
   int bh=NI_S(16); int btnY=LY_hdrY+NI_S(4);
   int xClose = LYP_x+LYP_w-NI_S(18);
   int xMin   = xClose-NI_S(20);
   int xView  = xMin-NI_S(38);
   int xTheme = xView-NI_S(26);
   NI_Button("btn_theme", xTheme, btnY, NI_S(24), bh, (g_ni_theme==1?"LT":"DK"), NI_C_BTN, NI_C_BTNTX);
   NI_Button("btn_view",  xView,  btnY, NI_S(36), bh, (g_ni_view==NIV_FULL?"FULL":"COMP"), NI_C_BTN, NI_C_BTNTX);
   NI_Button("btn_min",   xMin,   btnY, NI_S(18), bh, (g_ni_min?"[]":"_"), NI_C_BTN, NI_C_BTNTX);
   NI_Button("btn_close", xClose, btnY, NI_S(14), bh, "x", NI_C_BTN, NI_C_BTNTX);

   // status dot + word, placed to the LEFT of the theme button (no overlap)
   string st = NI_ConnStateText();
   color  sc = (st=="LIVE"?NI_C_LIVE:(st=="STALE"?NI_C_STALE:NI_C_OFF));
   int    sx = xTheme-NI_S(52);
   NI_Rect("stdot", sx, LY_hdrY+NI_S(9), NI_S(8), NI_S(8), sc, sc);
   NI_Label("sttext", sx+NI_S(11), LY_hdrY+NI_S(6), st, sc, NI_S(8), "Arial Bold");
}

//------------------------------------------------------------------
// NEXT HIGH IMPACT strip
//------------------------------------------------------------------
void NI_DrawNextHigh()
{
   NI_Rect("next", LYP_x, LY_nextY, LYP_w, LY_nextH, NI_C_PANEL, NI_C_BORDER);
   string oId,oCcy,oName; long oUtc;
   int idx = NI_ResolveNextHigh(oId,oCcy,oName,oUtc);
   if(oUtc<=0)
   {
      NI_Label("next_txt", LYP_x+NI_S(8), LY_nextY+NI_S(5),
               "NEXT HIGH: none upcoming", NI_C_DIM, NI_S(8), "Arial");
      NI_LabelR("next_cd", LYP_x+LYP_w-NI_S(8), LY_nextY+NI_S(5), "", NI_C_DIM, NI_S(8), "Arial");
      return;
   }
   string txt = "NEXT HIGH: "+oCcy+"  "+oName;
   NI_Label("next_txt", LYP_x+NI_S(8), LY_nextY+NI_S(5), txt, NI_C_TXT, NI_S(8), "Arial Bold");
   string cd = NI_CountdownText(oUtc);
   int stt = NI_EventState(oUtc);
   string cdtxt = (stt==NI_EV_NOW?"EVENT NOW":(cd==""?"":cd))+"  "+NI_HhMm(oUtc);
   NI_LabelR("next_cd", LYP_x+LYP_w-NI_S(8), LY_nextY+NI_S(5), cdtxt, NI_C_HIGH, NI_S(8), "Arial Bold");
}

//------------------------------------------------------------------
// TAB BAR
//------------------------------------------------------------------
void NI_DrawTabBar()
{
   NI_Rect("tabbar", LYP_x, LY_tabY, LYP_w, LY_tabH, NI_C_INNER, NI_C_BORDER);
   int n=NITAB_COUNT;
   int bw=LYP_w/n;
   for(int t=0;t<n;t++)
   {
      int bx=LYP_x + t*bw;
      color bg = (t==g_ni_tab? NI_C_ACCENT : NI_C_BTN);
      color tx = (t==g_ni_tab? NI_C_PANEL  : NI_C_BTNTX);
      NI_Button("tab"+IntegerToString(t), bx, LY_tabY+NI_S(2), bw-NI_S(1), LY_tabH-NI_S(4),
                NI_TabLabel(t), bg, tx);
   }
}

//------------------------------------------------------------------
// BODY: HEAT (rect-parameterised so it serves compact + full-left-column)
//------------------------------------------------------------------
void NI_DrawHeatRect(int rx, int ry, int rw, int rh_area, string idpfx)
{
   int y=ry+NI_S(2);
   int rh=NI_S(20);
   int barX=rx+NI_S(56);
   int barW=rw-NI_S(140);
   if(barW<NI_S(40)) barW=NI_S(40);
   for(int i=0;i<NI_NCCY;i++)
   {
      string c=NI_CCY[i];
      int score=NI_HeatScore(c);
      string band=NI_HeatBand(c);
      string sfx=idpfx+IntegerToString(i);
      NI_Label("h_ccy"+sfx, rx+NI_S(6), y+NI_S(4), c, NI_C_TXT, NI_S(8), "Arial Bold");
      NI_Rect("h_bg"+sfx, barX, y+NI_S(4), barW, NI_S(9), NI_C_INNER, NI_C_BORDER);
      int fillW = (score<0?0:(int)((double)barW*score/100.0));
      if(fillW>0)
         NI_Rect("h_fl"+sfx, barX, y+NI_S(4), fillW, NI_S(9), NI_BandColor(band), NI_BandColor(band));
      else
         NI_Rect("h_fl"+sfx, barX, y+NI_S(4), 1, NI_S(9), NI_C_INNER, NI_C_INNER);
      NI_LabelR("h_sc"+sfx, rx+rw-NI_S(46), y+NI_S(3),
                (score<0?"-":IntegerToString(score)), NI_C_TXT, NI_S(8), "Arial Bold");
      NI_LabelR("h_bd"+sfx, rx+rw-NI_S(6), y+NI_S(3),
                band, NI_BandColor(band), NI_S(8), "Arial");
      y+=rh;
   }
   NI_Label("h_cap"+idpfx, rx+NI_S(6), y+NI_S(2),
            "News activity / risk - not a buy/sell signal", NI_C_DIM, NI_S(7), "Arial");
}

// compact HEAT tab uses the full body rect
void NI_DrawHeatTab()
{
   NI_DrawHeatRect(LYP_x, LY_bodyY, LYP_w, LY_bodyH, "");
}

//------------------------------------------------------------------
// BODY: paged list helper (returns page label)
//------------------------------------------------------------------
void NI_DrawPager(string idbase, int page, int itemCount, int perPage)
{
   int pc = NI_PageCount(itemCount, perPage);
   int py = LY_footY - NI_S(16);
   NI_Button(idbase+"_prev", LYP_x+NI_S(8),  py, NI_S(22), NI_S(14), "<", NI_C_BTN, NI_C_BTNTX);
   NI_Button(idbase+"_next", LYP_x+NI_S(34), py, NI_S(22), NI_S(14), ">", NI_C_BTN, NI_C_BTNTX);
   NI_Label(idbase+"_lbl", LYP_x+NI_S(60), py+NI_S(2),
            "Page "+IntegerToString(page+1)+"/"+IntegerToString(pc), NI_C_DIM, NI_S(7), "Arial");
}

// positioned pager (FULL columns): explicit x/y anchor
void NI_DrawPagerAt(string idbase, int px, int py, int page, int itemCount, int perPage)
{
   int pc = NI_PageCount(itemCount, perPage);
   NI_Button(idbase+"_prev", px+NI_S(2),  py, NI_S(18), NI_S(13), "<", NI_C_BTN, NI_C_BTNTX);
   NI_Button(idbase+"_next", px+NI_S(22), py, NI_S(18), NI_S(13), ">", NI_C_BTN, NI_C_BTNTX);
   NI_Label(idbase+"_lbl", px+NI_S(44), py+NI_S(2),
            IntegerToString(page+1)+"/"+IntegerToString(pc), NI_C_DIM, NI_S(7), "Arial");
}

//------------------------------------------------------------------
// BODY: CALENDAR tab (paged events, filtered)
//------------------------------------------------------------------
void NI_DrawCalTab()
{
   NI_BuildFilteredEvents();
   int perPage = LY_rowsPerPage-1; if(perPage<1) perPage=1;
   g_ni_pageCal = NI_ClampPage(g_ni_pageCal, g_ni_evN, perPage);
   int start=g_ni_pageCal*perPage;
   int y=LY_bodyY+NI_S(2); int rh=NI_S(20);
   // header row
   NI_Label("cal_h", LYP_x+NI_S(8), y, "TIME  CUR EVENT                IMP", NI_C_DIM, NI_S(7), "Arial");
   y+=NI_S(14);
   for(int r=0;r<perPage;r++)
   {
      int fi=start+r;
      string s=IntegerToString(r);
      if(fi>=g_ni_evN){ NI_Label("cal"+s,LYP_x+NI_S(8),y,"",NI_C_TXT,NI_S(7),"Arial"); NI_Label("cal_i"+s,LYP_x+LYP_w-NI_S(30),y,"",NI_C_DIM,NI_S(7),"Arial"); y+=rh; continue; }
      int i=g_ni_evIdx[fi];
      string line=NI_HhMm(ev_utc[i])+" "+ev_currency[i]+" "+ev_name[i];
      if(StringLen(line)>34) line=StringSubstr(line,0,34);
      NI_Label("cal"+s, LYP_x+NI_S(8), y, line, NI_C_TXT, NI_S(7), "Arial");
      NI_LabelR("cal_i"+s, LYP_x+LYP_w-NI_S(8), y, NI_ImpactWord(ev_impact[i]),
                NI_ImpactColor(ev_impact[i]), NI_S(7), "Arial Bold");
      y+=rh;
   }
   NI_DrawPager("cal_pg", g_ni_pageCal, g_ni_evN, perPage);
}

//------------------------------------------------------------------
// BODY: HEADLINES tab (paged, with SOURCE, filtered)
//------------------------------------------------------------------
void NI_DrawNewsTab()
{
   NI_BuildFilteredHeadlines();
   int perPage = LY_rowsPerPage-1; if(perPage<1) perPage=1;
   g_ni_pageNews = NI_ClampPage(g_ni_pageNews, g_ni_hlN, perPage);
   int start=g_ni_pageNews*perPage;
   int y=LY_bodyY+NI_S(2); int rh=NI_S(20);
   NI_Label("nw_h", LYP_x+NI_S(8), y, "TIME  CUR HEADLINE            SRC", NI_C_DIM, NI_S(7), "Arial");
   y+=NI_S(14);
   for(int r=0;r<perPage;r++)
   {
      int fi=start+r; string s=IntegerToString(r);
      if(fi>=g_ni_hlN){ NI_Label("nw"+s,LYP_x+NI_S(8),y,"",NI_C_TXT,NI_S(7),"Arial"); NI_Label("nw_s"+s,LYP_x+LYP_w-NI_S(30),y,"",NI_C_DIM,NI_S(7),"Arial"); y+=rh; continue; }
      int i=g_ni_hlIdx[fi];
      string line=NI_HhMm(hl_utc[i])+" "+hl_currency[i]+" "+hl_title[i];
      if(StringLen(line)>34) line=StringSubstr(line,0,34);
      NI_Label("nw"+s, LYP_x+NI_S(8), y, line, NI_C_TXT, NI_S(7), "Arial");
      NI_LabelR("nw_s"+s, LYP_x+LYP_w-NI_S(8), y, hl_source[i], NI_C_DIM, NI_S(7), "Arial");
      y+=rh;
   }
   NI_DrawPager("nw_pg", g_ni_pageNews, g_ni_hlN, perPage);
}

//------------------------------------------------------------------
// BODY: IMPACT MONITOR (HIGH-impact events + state, filtered by ccy/time)
//------------------------------------------------------------------
void NI_DrawImpactTab()
{
   int y=LY_bodyY+NI_S(2); int rh=NI_S(22);
   NI_Label("im_h", LYP_x+NI_S(8), y, "HIGH-IMPACT EVENTS", NI_C_DIM, NI_S(7), "Arial");
   y+=NI_S(14);
   int shown=0; int perPage=LY_rowsPerPage-1; if(perPage<1) perPage=1;
   for(int i=0;i<g_nEvents && shown<perPage;i++)
   {
      if(ev_impact[i]!=NI_IMP_HIGH) continue;              // impact monitor is HIGH by definition
      if(!NI_FilterCcy(ev_currency[i])) continue;          // honour currency filter
      if(!NI_FilterTime(ev_utc[i])) continue;              // honour time filter
      string s=IntegerToString(shown);
      int stt=NI_EventState(ev_utc[i]);
      string state=(stt==NI_EV_UPCOMING?NI_CountdownText(ev_utc[i]):(stt==NI_EV_NOW?"EVENT NOW":"DONE"));
      string line=ev_currency[i]+"  "+ev_name[i];
      if(StringLen(line)>28) line=StringSubstr(line,0,28);
      NI_Label("im"+s, LYP_x+NI_S(8), y, line, NI_C_TXT, NI_S(8), "Arial Bold");
      NI_LabelR("im_s"+s, LYP_x+LYP_w-NI_S(8), y, state, NI_C_HIGH, NI_S(8), "Arial");
      y+=rh; shown++;
   }
   if(shown==0)
      NI_Label("im0", LYP_x+NI_S(8), y, "No high-impact events (filtered)", NI_C_DIM, NI_S(8), "Arial");
}

//------------------------------------------------------------------
// BODY: CURRENCY CONTEXT (strength x heat -> approved phrase)
//------------------------------------------------------------------
void NI_DrawCtxTab()
{
   int y=LY_bodyY+NI_S(2); int rh=NI_S(20);
   NI_Label("ctx_h", LYP_x+NI_S(8), y, "STRENGTH x NEWS HEAT (context only)", NI_C_DIM, NI_S(7), "Arial");
   y+=NI_S(14);
   int perPage=LY_rowsPerPage-1; if(perPage<1) perPage=1;
   int shown=0;
   for(int i=0;i<NI_NCCY && shown<perPage;i++)
   {
      string c=NI_CCY[i]; string s=IntegerToString(i);
      NI_Label("cx_c"+s, LYP_x+NI_S(8), y, c+" "+NI_StrengthText(c), NI_C_TXT, NI_S(8), "Arial Bold");
      NI_LabelR("cx_p"+s, LYP_x+LYP_w-NI_S(8), y, NI_ContextLabel(c), NI_C_DIM, NI_S(7), "Arial");
      y+=rh; shown++;
   }
}

//------------------------------------------------------------------
// BODY: CURRENCY BATTLE (independent strength, two currencies)
//------------------------------------------------------------------
void NI_DrawBattleTab()
{
   int y=LY_bodyY+NI_S(4);
   string a=NI_CCY[g_ni_battleA];
   string b=NI_CCY[g_ni_battleB];
   NI_Label("bt_h", LYP_x+NI_S(8), y, "CURRENCY BATTLE (News Intelligence, independent)", NI_C_DIM, NI_S(7), "Arial");
   y+=NI_S(18);
   // A row
   NI_Label("bt_a", LYP_x+NI_S(8), y, a+"  "+NI_StrengthText(a), NI_C_TXT, NI_S(10), "Arial Bold");
   NI_LabelR("bt_ah", LYP_x+LYP_w-NI_S(8), y, "NEWS HEAT "+NI_HeatBand(a), NI_BandColor(NI_HeatBand(a)), NI_S(8), "Arial");
   y+=NI_S(22);
   NI_Label("bt_vs", LYP_x+NI_S(8), y, "vs", NI_C_DIM, NI_S(9), "Arial");
   y+=NI_S(22);
   // B row
   NI_Label("bt_b", LYP_x+NI_S(8), y, b+"  "+NI_StrengthText(b), NI_C_TXT, NI_S(10), "Arial Bold");
   NI_LabelR("bt_bh", LYP_x+LYP_w-NI_S(8), y, "NEWS HEAT "+NI_HeatBand(b), NI_BandColor(NI_HeatBand(b)), NI_S(8), "Arial");
   y+=NI_S(26);
   // neutral, data-based interpretation (NO buy/sell)
   NI_Label("bt_i", LYP_x+NI_S(8), y, a+": "+NI_ContextLabel(a), NI_C_DIM, NI_S(7), "Arial");
   y+=NI_S(14);
   NI_Label("bt_i2", LYP_x+NI_S(8), y, b+": "+NI_ContextLabel(b), NI_C_DIM, NI_S(7), "Arial");
   y+=NI_S(16);
   NI_Label("bt_note", LYP_x+NI_S(8), y, "Context only - not a trade signal.", NI_C_DIM, NI_S(7), "Arial");
   // battle selector buttons
   NI_Button("bt_selA", LYP_x+LYP_w-NI_S(60), LY_bodyY+NI_S(22), NI_S(24), NI_S(14), "A>", NI_C_BTN, NI_C_BTNTX);
   NI_Button("bt_selB", LYP_x+LYP_w-NI_S(60), LY_bodyY+NI_S(66), NI_S(24), NI_S(14), "B>", NI_C_BTN, NI_C_BTNTX);
}

//------------------------------------------------------------------
// FOOTER (fixture guard, timezone, last update)
//------------------------------------------------------------------
void NI_DrawFooter()
{
   NI_Rect("foot", LYP_x, LY_footY, LYP_w, LY_footH, NI_C_INNER, NI_C_BORDER);
   // fixture guard - surfaced so fixture data is never shown as genuine live
   string guard = (g_feedSimulated ? (g_feed_kind+" - simulated") : "PRODUCTION - live");
   color gc = (g_feedSimulated ? NI_C_STALE : NI_C_LIVE);
   NI_Label("foot_guard", LYP_x+NI_S(8), LY_footY+NI_S(4), guard, gc, NI_S(7), "Arial Bold");
   // timezone label
   string tz = (NI_Timezone==NI_TZ_UTC?"UTC":(NI_Timezone==NI_TZ_LOCAL?"Local":"Broker"));
   NI_LabelR("foot_tz", LYP_x+LYP_w-NI_S(70), LY_footY+NI_S(4), "tz: "+tz, NI_C_DIM, NI_S(7), "Arial");
   // last update = server_utc rendered
   NI_LabelR("foot_upd", LYP_x+LYP_w-NI_S(8), LY_footY+NI_S(4), NI_HhMm(g_server_utc), NI_C_DIM, NI_S(7), "Arial");
}

//------------------------------------------------------------------
// FULL VIEW: list region (CAL or NEWS) rendered into the right column
//------------------------------------------------------------------
void NI_DrawListRect(int rx, int ry, int rw, int rh_area)
{
   int rowsFit = rh_area/NI_S(18); if(rowsFit<2) rowsFit=2;
   int perPage = rowsFit-1;
   int y=ry+NI_S(2); int rh=NI_S(18);
   if(g_ni_fullList==NITAB_NEWS)
   {
      NI_BuildFilteredHeadlines();
      g_ni_pageNews=NI_ClampPage(g_ni_pageNews, g_ni_hlN, perPage);
      int start=g_ni_pageNews*perPage;
      NI_Label("fl_h", rx+NI_S(6), y, "HEADLINES  (CUR / SRC)", NI_C_DIM, NI_S(7), "Arial");
      y+=NI_S(13);
      for(int r=0;r<perPage;r++)
      {
         int fi=start+r; string s=IntegerToString(r);
         if(fi>=g_ni_hlN){ NI_Label("fl"+s,rx+NI_S(6),y,"",NI_C_TXT,NI_S(7),"Arial"); NI_Label("fl_s"+s,rx+rw-NI_S(30),y,"",NI_C_DIM,NI_S(7),"Arial"); y+=rh; continue; }
         int i=g_ni_hlIdx[fi];
         string line=NI_HhMm(hl_utc[i])+" "+hl_currency[i]+" "+hl_title[i];
         if(StringLen(line)>30) line=StringSubstr(line,0,30);
         NI_Label("fl"+s, rx+NI_S(6), y, line, NI_C_TXT, NI_S(7), "Arial");
         NI_LabelR("fl_s"+s, rx+rw-NI_S(6), y, hl_source[i], NI_C_DIM, NI_S(7), "Arial");
         y+=rh;
      }
      NI_DrawPagerAt("flnw_pg", rx, ry+rh_area-NI_S(15), g_ni_pageNews, g_ni_hlN, perPage);
   }
   else // CAL (default)
   {
      NI_BuildFilteredEvents();
      g_ni_pageCal=NI_ClampPage(g_ni_pageCal, g_ni_evN, perPage);
      int start=g_ni_pageCal*perPage;
      NI_Label("fl_h", rx+NI_S(6), y, "CALENDAR  (TIME / IMP)", NI_C_DIM, NI_S(7), "Arial");
      y+=NI_S(13);
      for(int r=0;r<perPage;r++)
      {
         int fi=start+r; string s=IntegerToString(r);
         if(fi>=g_ni_evN){ NI_Label("fl"+s,rx+NI_S(6),y,"",NI_C_TXT,NI_S(7),"Arial"); NI_Label("fl_i"+s,rx+rw-NI_S(30),y,"",NI_C_DIM,NI_S(7),"Arial"); y+=rh; continue; }
         int i=g_ni_evIdx[fi];
         string line=NI_HhMm(ev_utc[i])+" "+ev_currency[i]+" "+ev_name[i];
         if(StringLen(line)>30) line=StringSubstr(line,0,30);
         NI_Label("fl"+s, rx+NI_S(6), y, line, NI_C_TXT, NI_S(7), "Arial");
         NI_LabelR("fl_i"+s, rx+rw-NI_S(6), y, NI_ImpactWord(ev_impact[i]),
                   NI_ImpactColor(ev_impact[i]), NI_S(7), "Arial Bold");
         y+=rh;
      }
      NI_DrawPagerAt("flcal_pg", rx, ry+rh_area-NI_S(15), g_ni_pageCal, g_ni_evN, perPage);
   }
   // list-region toggle CAL<->NEWS
   NI_ButtonSel("fl_toggle", rx+rw-NI_S(70), ry-NI_S(1), NI_S(64), NI_S(13),
                (g_ni_fullList==NITAB_NEWS?"list: NEWS":"list: CAL"), true);
}

// FULL impact strip (bottom of body): HIGH events with state
void NI_DrawImpactStrip(int rx, int ry, int rw, int rh_area)
{
   NI_Rect("imp_strip", rx, ry, rw, rh_area, NI_C_INNER, NI_C_BORDER);
   int y=ry+NI_S(3);
   NI_Label("is_h", rx+NI_S(6), y, "NEWS IMPACT MONITOR (HIGH)", NI_C_DIM, NI_S(7), "Arial");
   y+=NI_S(13);
   int perRow = rh_area/NI_S(16)-1; if(perRow<1) perRow=1;
   int shown=0;
   for(int i=0;i<g_nEvents && shown<perRow;i++)
   {
      if(ev_impact[i]!=NI_IMP_HIGH) continue;
      if(!NI_FilterCcy(ev_currency[i])) continue;
      if(!NI_FilterTime(ev_utc[i])) continue;
      string s=IntegerToString(shown);
      int stt=NI_EventState(ev_utc[i]);
      string state=(stt==NI_EV_UPCOMING?NI_CountdownText(ev_utc[i]):(stt==NI_EV_NOW?"EVENT NOW":"DONE"));
      string line=ev_currency[i]+"  "+ev_name[i];
      if(StringLen(line)>34) line=StringSubstr(line,0,34);
      NI_Label("is"+s, rx+NI_S(6), y, line, NI_C_TXT, NI_S(7), "Arial Bold");
      NI_LabelR("is_s"+s, rx+rw-NI_S(6), y, state, NI_C_HIGH, NI_S(7), "Arial");
      y+=NI_S(16); shown++;
   }
   if(shown==0)
      NI_Label("is0", rx+NI_S(6), y, "No high-impact events (filtered)", NI_C_DIM, NI_S(7), "Arial");
}

//------------------------------------------------------------------
// FULL BODY: heat (left) + list (right) + impact strip (bottom)
//------------------------------------------------------------------
void NI_DrawFullBody()
{
   int topH = LYF_impY - LY_bodyY - NI_S(2);
   if(topH < NI_S(80)) topH = NI_S(80);
   // left column: heat
   NI_DrawHeatRect(LYF_colHeatX, LY_bodyY, LYF_colHeatW, topH, "F");
   // right column: list (CAL default / NEWS selectable)
   NI_DrawListRect(LYF_colListX, LY_bodyY, LYF_colListW, topH);
   // bottom: impact strip across full width
   NI_DrawImpactStrip(LYP_x+NI_S(2), LYF_impY, LYP_w-NI_S(4), LYF_impH);
}

//------------------------------------------------------------------
// BODY dispatcher (compact = active tab; full = multi-region)
//------------------------------------------------------------------
void NI_DrawBody()
{
   if(g_ni_view==NIV_FULL)
   {
      NI_DrawFullBody();
      return;
   }
   if(g_ni_tab==NITAB_HEAT)   { NI_DrawHeatTab();   return; }
   if(g_ni_tab==NITAB_CAL)    { NI_DrawCalTab();    return; }
   if(g_ni_tab==NITAB_NEWS)   { NI_DrawNewsTab();   return; }
   if(g_ni_tab==NITAB_IMPACT) { NI_DrawImpactTab(); return; }
   if(g_ni_tab==NITAB_CTX)    { NI_DrawCtxTab();    return; }
   NI_DrawBattleTab();
}

//------------------------------------------------------------------
// FULL PANEL BUILD
//------------------------------------------------------------------
void NI_BuildPanel()
{
   if(!NI_ShowPanel) return;
   NI_DeleteAllNI();
   NI_ApplyTheme(g_ni_theme);
   NI_SolveLayout();

   NI_DrawHeader();
   if(g_ni_min){ g_ni_built=true; ChartRedraw(0); return; }

   NI_DrawNextHigh();
   NI_DrawTabBar();
   // Stage 4: filter row drawn on every tab for a consistent layout (the solver
   // always reserves the band). In COMPACT the time filter is omitted (space);
   // in FULL all three filters show. Filters affect CAL/NEWS/IMPACT display.
   NI_DrawFilterRow();
   NI_DrawBody();
   NI_DrawFooter();

   g_ni_built=true;
   ChartRedraw(0);
}

// refresh only dynamic text (countdowns/status) without full rebuild
void NI_RefreshDynamic()
{
   if(!NI_ShowPanel || !g_ni_built || g_ni_min) return;
   // recompute next-high strip + status dot + footer update time
   NI_DrawNextHigh();
   // status
   string st = NI_ConnStateText();
   color  sc = (st=="LIVE"?NI_C_LIVE:(st=="STALE"?NI_C_STALE:NI_C_OFF));
   NI_Label("sttext", LYP_x+LYP_w-NI_S(108), LY_hdrY+NI_S(6), st, sc, NI_S(8), "Arial Bold");
   NI_LabelR("foot_upd", LYP_x+LYP_w-NI_S(8), LY_footY+NI_S(4), NI_HhMm(g_server_utc), NI_C_DIM, NI_S(7), "Arial");
   // if the active tab shows countdowns, refresh it
   if(g_ni_tab==NITAB_IMPACT && g_ni_view!=NIV_FULL) NI_DrawImpactTab();
   ChartRedraw(0);
}

void NI_DestroyPanel()
{
   NI_DeleteAllNI();
   g_ni_built=false;
   ChartRedraw(0);
}
//+------------------------------------------------------------------+
//| 90_ui_events.mqh - Stage 3/4 chart-event handling                |
//|                                                                   |
//| Handles clicks + header drag on NI_-prefixed objects only. Never  |
//| touches any PowerMap object. All handlers change DISPLAY state    |
//| (tab, page, view, theme, filters, battle, position) and rebuild   |
//| the NI panel - they never mutate engine stores.                   |
//+------------------------------------------------------------------+

// reset a button's pressed state so it doesn't stick down
void NI_UnpressButton(string nm)
{
   if(ObjectFind(0,nm)>=0)
      ObjectSetInteger(0,nm,OBJPROP_STATE,false);
}

// cycle currency filter: ALL -> USD..XAU -> ALL
void NI_CycleCcyFilter()
{
   g_ni_fCcy++;
   if(g_ni_fCcy>=NI_NCCY) g_ni_fCcy=-1;   // wrap back to ALL
   g_ni_pageCal=0; g_ni_pageNews=0;       // reset paging when filter changes
}
// cycle impact filter: ALL -> HIGH -> MED -> LOW -> ALL
void NI_CycleImpactFilter()
{
   if(g_ni_fImpact==0) g_ni_fImpact=NI_IMP_HIGH;
   else if(g_ni_fImpact==NI_IMP_HIGH) g_ni_fImpact=NI_IMP_MED;
   else if(g_ni_fImpact==NI_IMP_MED)  g_ni_fImpact=NI_IMP_LOW;
   else g_ni_fImpact=0;
   g_ni_pageCal=0; g_ni_pageNews=0;
}
// cycle time filter: ALL -> UPCOMING -> TODAY -> PAST -> ALL
void NI_CycleTimeFilter()
{
   g_ni_fTime=(g_ni_fTime+1)%4;
   g_ni_pageCal=0; g_ni_pageNews=0;
}

// returns true if handled
bool NI_HandleClick(string sparam)
{
   // only react to our own objects
   if(StringFind(sparam,NIP)!=0) return false;

   string id = StringSubstr(sparam, StringLen(NIP)); // strip "NI_"

   // --- header controls ---
   if(id=="btn_close"){ NI_UnpressButton(sparam); NI_DestroyPanel(); return true; }
   if(id=="btn_min")
   {
      NI_UnpressButton(sparam);
      if(!g_ni_min)  // going minimised: remember current effective view + tab
      {
         g_ni_savedView=g_ni_view; g_ni_savedTab=g_ni_tab; g_ni_min=true;
      }
      else           // restoring: reassert the remembered view via the override
      {
         g_ni_min=false; g_ni_viewOverride=g_ni_savedView; g_ni_tab=g_ni_savedTab;
      }
      NI_BuildPanel(); return true;
   }
   if(id=="btn_view") { NI_UnpressButton(sparam);
                        // flip the CURRENT effective view and lock it as an override
                        int cur = g_ni_view;
                        g_ni_viewOverride = (cur==NIV_FULL ? NIV_COMPACT : NIV_FULL);
                        NI_BuildPanel(); return true; }
   if(id=="btn_theme"){ NI_UnpressButton(sparam); g_ni_theme=(g_ni_theme==1?0:1); NI_BuildPanel(); return true; }

   // --- tabs ---
   if(StringFind(id,"tab")==0 && StringLen(id)>=4)
   {
      string ns=StringSubstr(id,3);
      int t=(int)StringToInteger(ns);
      if(t>=0 && t<NITAB_COUNT){ g_ni_tab=t; NI_UnpressButton(sparam); NI_BuildPanel(); return true; }
   }

   // --- filters (display-only) ---
   if(id=="flt_ccy")  { NI_UnpressButton(sparam); NI_CycleCcyFilter();    NI_BuildPanel(); return true; }
   if(id=="flt_imp")  { NI_UnpressButton(sparam); NI_CycleImpactFilter(); NI_BuildPanel(); return true; }
   if(id=="flt_time") { NI_UnpressButton(sparam); NI_CycleTimeFilter();   NI_BuildPanel(); return true; }
   if(id=="flt_clear"){ NI_UnpressButton(sparam);
                        g_ni_fCcy=-1; g_ni_fImpact=0; g_ni_fTime=0;
                        g_ni_pageCal=0; g_ni_pageNews=0; NI_BuildPanel(); return true; }

   // --- full-view list region toggle CAL<->NEWS ---
   if(id=="fl_toggle"){ NI_UnpressButton(sparam);
                        g_ni_fullList=(g_ni_fullList==NITAB_NEWS?NITAB_CAL:NITAB_NEWS);
                        NI_BuildPanel(); return true; }

   // --- pagers (compact) ---
   if(id=="cal_pg_prev"){ NI_UnpressButton(sparam); g_ni_pageCal--; NI_BuildPanel(); return true; }
   if(id=="cal_pg_next"){ NI_UnpressButton(sparam); g_ni_pageCal++; NI_BuildPanel(); return true; }
   if(id=="nw_pg_prev") { NI_UnpressButton(sparam); g_ni_pageNews--; NI_BuildPanel(); return true; }
   if(id=="nw_pg_next") { NI_UnpressButton(sparam); g_ni_pageNews++; NI_BuildPanel(); return true; }
   // --- pagers (full columns) ---
   if(id=="flcal_pg_prev"){ NI_UnpressButton(sparam); g_ni_pageCal--; NI_BuildPanel(); return true; }
   if(id=="flcal_pg_next"){ NI_UnpressButton(sparam); g_ni_pageCal++; NI_BuildPanel(); return true; }
   if(id=="flnw_pg_prev") { NI_UnpressButton(sparam); g_ni_pageNews--; NI_BuildPanel(); return true; }
   if(id=="flnw_pg_next") { NI_UnpressButton(sparam); g_ni_pageNews++; NI_BuildPanel(); return true; }

   // --- battle selectors (cycle through the 9-currency universe) ---
   if(id=="bt_selA"){ NI_UnpressButton(sparam); g_ni_battleA=(g_ni_battleA+1)%NI_NCCY;
                      if(g_ni_battleA==g_ni_battleB) g_ni_battleA=(g_ni_battleA+1)%NI_NCCY;
                      NI_BuildPanel(); return true; }
   if(id=="bt_selB"){ NI_UnpressButton(sparam); g_ni_battleB=(g_ni_battleB+1)%NI_NCCY;
                      if(g_ni_battleB==g_ni_battleA) g_ni_battleB=(g_ni_battleB+1)%NI_NCCY;
                      NI_BuildPanel(); return true; }

   return false;
}

//------------------------------------------------------------------
// HEADER DRAG (Stage 4): move the whole panel by dragging the header.
// Uses raw mouse coords from CHARTEVENT_MOUSE_MOVE. lparam=x, dparam=y,
// sparam="1" while left button down. We grab when the press starts over
// the header band, then track until release. Chart scroll is disabled
// only during an active drag (PowerMap lesson) and restored after.
//------------------------------------------------------------------
bool NI_PointInHeader(int mx, int my)
{
   return (mx>=LYP_x && mx<=LYP_x+LYP_w && my>=LY_hdrY && my<=LY_hdrY+LY_hdrH);
}

void NI_HandleMouseMove(int mx, int my, string state)
{
   if(!NI_DragEnable) return;
   bool down = (state=="1");

   if(down && !g_ni_dragging)
   {
      // begin drag only if the press is on the header (and not on a header button:
      // buttons handle their own click; a small dead-zone avoids fighting them)
      if(NI_PointInHeader(mx,my) && mx < (LYP_x+LYP_w-NI_S(100)))
      {
         g_ni_dragging=true;
         g_ni_dragDX = mx-LYP_x;
         g_ni_dragDY = my-LYP_y;
         ChartSetInteger(0,CHART_MOUSE_SCROLL,false);   // freeze chart pan during drag
      }
   }
   else if(down && g_ni_dragging)
   {
      // move: update panel origin, keep it on-screen
      int nx=mx-g_ni_dragDX; int ny=my-g_ni_dragDY;
      if(nx<0) nx=0; if(ny<0) ny=0;
      NI_PanelX_rt=nx; NI_PanelY_rt=ny;
      NI_BuildPanel();
   }
   else if(!down && g_ni_dragging)
   {
      // release
      g_ni_dragging=false;
      ChartSetInteger(0,CHART_MOUSE_SCROLL,true);        // restore chart pan
   }
}
//+------------------------------------------------------------------+
//| 95_transport.mqh - Stage 5A additive WebRequest transport         |
//|                                                                   |
//| Adds a LIVE HTTPS fetch path for $CHbabastevo NEWS INTELLIGENCE.  |
//| It obtains a chb.newsintel.v1 JSON string over HTTPS and hands it |
//| to the EXISTING parser (NI_ParseFeed) - it does NOT duplicate the |
//| parser, schema, stores, heat, gold resolver, or state machine.    |
//|                                                                   |
//| FIXTURE mode (default) is unchanged. LIVE mode is opt-in via      |
//| inputs. On any transport failure the existing last-good stores    |
//| are preserved and the existing state machine decides STALE/OFF.   |
//|                                                                   |
//| PowerMap is never referenced. All logging is NI-tagged. No API    |
//| keys live here - only a Normaliser URL the user supplies.         |
//+------------------------------------------------------------------+

// ---- Stage 5A inputs (additive; default keeps pure FIXTURE behaviour) ------
input string NI5_Sep         = "===== NEWS INTELLIGENCE LIVE (Stage 5A) =====";
input bool   NI_LiveMode     = false;   // false = FIXTURE (default), true = LIVE HTTPS
input string NI_NormaliserURL= "https://raw.githubusercontent.com/USER/REPO/main/chb_newsintel_v1.json"; // static test endpoint
input int    NI_PollSeconds  = 60;      // min seconds between live fetches (never per-tick)
input int    NI_HttpTimeoutMs= 5000;    // bounded WebRequest timeout (never freezes MT4)
input bool   NI_LiveVerbose  = true;    // concise transport diagnostics in Experts

// ---- transport diagnostic codes (internal; UI unchanged) -------------------
#define NIX_IDLE            0
#define NIX_HTTP_SUCCESS    1
#define NIX_HTTP_ERROR      2
#define NIX_TIMEOUT         3
#define NIX_EMPTY_RESPONSE  4
#define NIX_INVALID_JSON    5
#define NIX_SCHEMA_MISMATCH 6
#define NIX_SERVER_OFFLINE  7

int      g_ni_lastTransport = NIX_IDLE;   // last transport result code
datetime g_ni_lastFetch     = 0;          // last time we attempted a live fetch
int      g_ni_lastHttp      = 0;          // last HTTP status code
bool     g_ni_haveLastGood  = false;      // do we hold a valid parsed snapshot?

string NI_TransportName(int code)
{
   if(code==NIX_HTTP_SUCCESS)    return "HTTP_SUCCESS";
   if(code==NIX_HTTP_ERROR)      return "HTTP_ERROR";
   if(code==NIX_TIMEOUT)         return "TIMEOUT";
   if(code==NIX_EMPTY_RESPONSE)  return "EMPTY_RESPONSE";
   if(code==NIX_INVALID_JSON)    return "INVALID_JSON";
   if(code==NIX_SCHEMA_MISMATCH) return "SCHEMA_MISMATCH";
   if(code==NIX_SERVER_OFFLINE)  return "SERVER_OFFLINE";
   return "IDLE";
}

void NI_LiveLog(string msg)
{
   if(NI_LiveVerbose) Print("CHB_NewsIntel: ", msg);
}

// quick pre-parse schema sniff so we can classify SCHEMA_MISMATCH distinctly
// from a genuine parse error. Looks for the frozen schema id token. This does
// NOT parse - the existing NI_ParseFeed remains the single source of truth.
bool NI_LooksLikeSchema(string body)
{
   return (StringFind(body, NI_SCHEMA_ID) >= 0);
}

// Perform one bounded HTTPS GET to the Normaliser and, on success, feed the
// body to the EXISTING parser. Returns true only if the existing parser
// accepted the payload. On any failure, leaves existing stores intact.
bool NI_LiveFetchOnce()
{
   g_ni_lastFetch = TimeCurrent();

   string url = NI_NormaliserURL;
   if(StringLen(url) < 8)
   {
      g_ni_lastTransport = NIX_HTTP_ERROR;
      NI_LiveLog("WebRequest failed: empty/invalid Normaliser URL");
      return false;
   }

   char   post[];    // no body for GET
   char   result[];
   string resultHeaders;
   string reqHeaders = "";

   NI_LiveLog("requesting Normaliser");
   ResetLastError();
   // MT4 WebRequest signature: (method, url, headers, timeout, data[], result[], result_headers)
   int status = WebRequest("GET", url, reqHeaders, NI_HttpTimeoutMs, post, result, resultHeaders);
   g_ni_lastHttp = status;

   if(status == -1)
   {
      int err = GetLastError();
      // 4060 = function not allowed (URL not whitelisted); 5203 = HTTP request failed
      if(err==5203) { g_ni_lastTransport = NIX_TIMEOUT; NI_LiveLog("WebRequest failed: timeout/connection (5203)"); }
      else          { g_ni_lastTransport = NIX_HTTP_ERROR; NI_LiveLog("WebRequest failed: err="+IntegerToString(err)+" (check URL whitelist in Tools>Options>Expert Advisors)"); }
      NI_LiveLog("retaining last-good snapshot");
      return false;
   }

   NI_LiveLog("HTTP "+IntegerToString(status));
   if(status != 200)
   {
      g_ni_lastTransport = NIX_HTTP_ERROR;
      NI_LiveLog("HTTP error = "+IntegerToString(status)+"; retaining last-good snapshot");
      return false;
   }

   // decode body
   string body = CharArrayToString(result, 0, ArraySize(result), CP_UTF8);
   if(StringLen(body) == 0)
   {
      g_ni_lastTransport = NIX_EMPTY_RESPONSE;
      NI_LiveLog("empty response; retaining last-good snapshot");
      return false;
   }

   // classify schema before handing to the parser (diagnostic only)
   if(!NI_LooksLikeSchema(body))
   {
      g_ni_lastTransport = NIX_SCHEMA_MISMATCH;
      NI_LiveLog("schema mismatch (missing "+NI_SCHEMA_ID+"); retaining last-good snapshot");
      return false;
   }

   // hand to the EXISTING parser - single source of truth
   bool ok = NI_ParseFeed(body);
   if(!ok)
   {
      g_ni_lastTransport = NIX_INVALID_JSON;
      NI_LiveLog("payload rejected by parser ("+g_lastError+"); retaining last-good snapshot");
      return false;
   }

   // success: mirror the existing fixture path's post-parse steps
   g_feedValid = true;
   g_ni_haveLastGood = true;
   g_ni_lastTransport = NIX_HTTP_SUCCESS;
   NI_EnforceFixtureGuard();
   NI_UpdateConnState();
   NI_LiveLog("schema "+NI_SCHEMA_ID);
   NI_LiveLog("payload parsed successfully");
   NI_LiveLog(NI_ConnStateText());
   return true;
}

// Poll gate: only fetch when LIVE mode is on and the poll interval elapsed.
// Never fetches per-tick. Called from the existing timer.
void NI_LivePollTick()
{
   if(!NI_LiveMode) return;
   int gap = (NI_PollSeconds>0 ? NI_PollSeconds : 60);
   if(g_ni_lastFetch!=0 && (TimeCurrent()-g_ni_lastFetch) < gap) return;
   NI_LiveFetchOnce();
   // refresh the UI through the existing render path (no UI redesign)
   NI_RefreshDynamic();
}

// One-time LIVE bootstrap at init: attempt an immediate fetch; if it fails,
// fall back to the already-loaded fixture stores (which OnInit loaded), so the
// UI always has something to show and PowerMap-style isolation is preserved.
void NI_LiveInit()
{
   if(!NI_LiveMode){ NI_LiveLog("FIXTURE mode (live disabled)"); return; }
   NI_LiveLog("WebRequest enabled");
   NI_LiveLog("URL: "+NI_NormaliserURL);
   bool ok = NI_LiveFetchOnce();
   if(!ok)
      NI_LiveLog("live bootstrap failed; showing last-good/fixture until next poll");
   NI_RefreshDynamic();
}
//+------------------------------------------------------------------+
//| 60_lifecycle.mqh - public API + self-test harness + lifecycle     |
//| ENGINE ONLY. Creates ZERO chart objects. All output goes to the   |
//| Experts log via Print(). NI_ prefix reserved for Phase 4.         |
//+------------------------------------------------------------------+

// Public: load + parse + guard + state a fixture file. Returns validity.
bool NI_LoadFeed(string fname)
{
   // Write-if-missing: if the fixture is absent, drop the embedded copy into
   // MQL4\Files\ once. Never overwrites an existing file.
   NI_EnsureFixture(fname);

   string json;
   if(!NI_LoadFixtureFile(fname, json))
   {
      g_feedValid=false;
      // on load failure, engine stays in last-good cache if any (see caller)
      return false;
   }
   bool ok=NI_ParseFeed(json);
   g_feedValid=ok;
   if(ok)
   {
      NI_EnforceFixtureGuard();
      NI_UpdateConnState();
   }
   return ok;
}

//==================================================================
// LAST-GOOD CACHE (engine-level): snapshot scalar + counts of the
// last VALID feed so a subsequent load failure can be reported while
// keeping the previously-good data available. Flat snapshot only.
//==================================================================
bool   gc_valid=false;
string gc_schema, gc_kind, gc_status;
long   gc_server_utc;
int    gc_nEvents, gc_nHeadlines, gc_nHeat;

void NI_CacheStoreGood()
{
   if(!g_feedValid) return;
   gc_valid=true;
   gc_schema=g_schema; gc_kind=g_feed_kind; gc_status=g_status;
   gc_server_utc=g_server_utc;
   gc_nEvents=g_nEvents; gc_nHeadlines=g_nHeadlines; gc_nHeat=g_nHeat;
}

//==================================================================
// SELF-TEST HARNESS
// Runs the acceptance checks against the currently loaded feed and
// prints results. Returns number of failures.
//==================================================================
int  T_pass=0, T_fail=0;
void T_check(string name, bool cond)
{
   if(cond){ T_pass++; Print("  ok   ",name); }
   else    { T_fail++; Print("  FAIL ",name); }
}

int NI_RunAcceptance()
{
   T_pass=0; T_fail=0;
   Print("=== $CHbabastevo News Intelligence - Phase 3 acceptance ===");

   // load default fixture
   bool okLoad = NI_LoadFeed(NI_FixtureFile);
   T_check("default fixture loads & parses", okLoad);
   if(!okLoad){ Print("load error: ", g_lastError); return T_fail; }
   NI_CacheStoreGood();

   // 1 schema id
   T_check("schema == chb.newsintel.v1", g_schema==NI_SCHEMA_ID);
   // 2 feed_kind / simulated guard
   T_check("feed_kind == FIXTURE", g_feed_kind==NI_KIND_FIXTURE);
   T_check("simulated flag true", g_simulated==true);
   T_check("guard: engine marks feed simulated", g_feedSimulated==true);
   T_check("guard: not treated as genuine live data", NI_IsGenuineLiveData()==false);
   // 3 status independence (FIXTURE + LIVE is valid)
   T_check("status is LIVE (independent of feed_kind)", g_status==NI_ST_LIVE);
   T_check("conn state text == LIVE", NI_ConnStateText()=="LIVE");
   // 4 all 9 heat currencies
   bool all9=(g_nHeat==NI_NCCY);
   for(int i=0;i<NI_NCCY;i++) if(NI_HeatScore(NI_CCY[i])<0) all9=false;
   T_check("heat has all 9 currencies incl XAU", all9);
   // 5 heat band thresholds consumed (not recomputed): USD 67 HIGH from fixture
   T_check("USD heat score == 67", NI_HeatScore("USD")==67);
   T_check("USD heat band == HIGH", NI_HeatBand("USD")=="HIGH");
   T_check("XAU heat present (first-class)", NI_HeatScore("XAU")>=0);
   // 6 next-high eligibility (utc > server_utc); fixture -> usd-fed-rate
   string oId,oCcy,oName; long oUtc;
   int nhIdx=NI_ResolveNextHigh(oId,oCcy,oName,oUtc);
   T_check("next-high resolves to an upcoming HIGH", oUtc>g_server_utc);
   T_check("next-high id == usd-fed-rate", oId=="usd-fed-rate");
   T_check("next-high currency == USD", oCcy=="USD");
   // expired HIGH (usd-ppi-justposted, -8m) must NOT be next-high
   T_check("expired HIGH not selected as next-high", oId!="usd-ppi-justposted");
   // 7 countdown never positive for an expired event.
   // NOTE: NI_CountdownText measures against the LIVE clock NI_NowUtc(), so the
   // test events must be built relative to NI_NowUtc() too - NOT the fixture's
   // frozen server_utc (which is in the past once the fixture is loaded later).
   long nowRef=NI_NowUtc();
   T_check("expired event countdown empty", NI_CountdownText(nowRef-3600)=="");
   T_check("upcoming event countdown non-empty", StringLen(NI_CountdownText(nowRef+600))>0);
   // event lifecycle transitions
   T_check("event far future => UPCOMING", NI_EventState(NI_NowUtc()+7200)==NI_EV_UPCOMING);
   T_check("event at now => NOW", NI_EventState(NI_NowUtc())==NI_EV_NOW);
   T_check("event far past => COMPLETED", NI_EventState(NI_NowUtc()-7200)==NI_EV_COMPLETED);
   // 8 data validation: impacts in range, empty fields tolerated
   bool impOk=true;
   for(int e=0;e<g_nEvents;e++) if(ev_impact[e]<0||ev_impact[e]>3) impOk=false;
   T_check("all event impacts in {0..3}", impOk);
   bool hlImpOk=true;
   for(int hh=0;hh<g_nHeadlines;hh++) if(hl_impact[hh]<0||hl_impact[hh]>3) hlImpOk=false;
   T_check("all headline impacts in {0..3}", hlImpOk);
   // 9 SOURCE validation: every headline source != "" in default feed
   bool srcOk=true;
   for(int s=0;s<g_nHeadlines;s++) if(hl_source[s]=="") srcOk=false;
   T_check("every headline has source != \"\"", srcOk);
   // 10 sentiment null + empty url tolerated (at least one each expected)
   bool sawNullSent=false; for(int s2=0;s2<g_nHeadlines;s2++) if(!hl_hasSentiment[s2]) sawNullSent=true;
   T_check("null sentiment handled (>=1 present)", sawNullSent);
   bool sawEmptyUrl=false; for(int s3=0;s3<g_nHeadlines;s3++) if(hl_url[s3]=="") sawEmptyUrl=true;
   T_check("empty url handled (>=1 present)", sawEmptyUrl);
   // XAU mapping: a GOLD-term event mapped to XAU currency
   bool xauEvt=false; for(int e2=0;e2<g_nEvents;e2++) if(ev_currency[e2]=="XAU") xauEvt=true;
   T_check("XAU/GOLD event mapped to XAU", xauEvt);

   Print("=== acceptance: ", T_pass, " passed, ", T_fail, " failed ===");
   return T_fail;
}

//==================================================================
// LIFECYCLE
//==================================================================
int OnInit()
{
   NI_InitConst();
   NI_InitFiat();
   NI_InitStores();

   // No chart objects. No WebRequest. Engine only.
   Print("CHB News Intelligence ENGINE v3.11 (Stage 5A: additive LIVE WebRequest transport into existing parser; FIXTURE default; NI_ namespace; PowerMap untouched)");
   Print("Fixture file: ", NI_FixtureFile, "  Timezone mode: ", NI_Timezone);

   if(NI_RunSelfTest)
      NI_RunAcceptance();

   // strength context is a live-price read; in the tester/log it may be n/a if
   // symbols are absent - that is expected and never fabricated.
   NI_ComputeStrengthContext();
   string goldNote = (g_goldSymbol=="") ? "(no broker gold symbol found)" : "(broker sym: "+g_goldSymbol+")";
   Print("Strength context (independent): USD ", NI_StrengthText("USD"),
         " | EUR ", NI_StrengthText("EUR"), " | XAU ", NI_StrengthText("XAU"), " ", goldNote);

   // --- Stage 3 (additive): load feed for display + build standalone NI panel.
   // The engine self-test above already ran on NI_FixtureFile. Ensure the feed
   // is loaded into the stores for the UI to read, then draw the NI_ panel.
   // No WebRequest, no PowerMap contact; all objects are NI_-prefixed.
   g_ni_theme = NI_ThemeMode;
   g_ni_view  = NIV_COMPACT;
   // Stage 4: initialise runtime-mutable position from inputs; set full list default
   NI_PanelX_rt = NI_PanelX;
   NI_PanelY_rt = NI_PanelY;
   g_ni_fullList = (NI_FullListDef==1 ? NITAB_NEWS : NITAB_CAL);
   if(NI_ShowPanel)
   {
      if(!g_feedValid) NI_LoadFeed(NI_FixtureFile);   // populate stores for display
      NI_BuildPanel();
      EventSetTimer(NI_RefreshSec>0 ? NI_RefreshSec : 1);
      // Stage 4: enable mouse-move events so header drag works (drag is opt-out
      // via NI_DragEnable). This affects only this chart's event stream.
      if(NI_DragEnable)
         ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,true);
      // Stage 5A (additive): LIVE transport bootstrap. In FIXTURE mode this is a
      // no-op log line; in LIVE mode it attempts one HTTPS fetch and falls back
      // to the fixture stores already loaded above. Never touches PowerMap.
      NI_LiveInit();
   }

   return(INIT_SUCCEEDED);
}

// Stage 3 (additive): timer refreshes dynamic UI text (countdowns/status).
// Stage 5A (additive): also drives the bounded live poll (gated; never per-tick).
void OnTimer()
{
   NI_RefreshDynamic();
   NI_LivePollTick();
}

// Stage 3/4 (additive): route NI_ button clicks + header drag to UI handlers.
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if(id==CHARTEVENT_OBJECT_CLICK)
      NI_HandleClick(sparam);
   else if(id==CHARTEVENT_MOUSE_MOVE)
      NI_HandleMouseMove((int)lparam, (int)dparam, sparam);
}

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   // Engine layer: no drawing. Recompute strength context on new bars only.
   static datetime lastBar=0;
   if(rates_total>0 && time[rates_total-1]!=lastBar)
   {
      lastBar=time[rates_total-1];
      NI_ComputeStrengthContext();
   }
   return(rates_total);
}

void OnDeinit(const int reason)
{
   // Stage 3/4 (additive): remove the NI_ panel, stop the timer, and restore the
   // chart event/scroll settings the UI changed. Engine itself still creates no
   // objects; this only cleans up the standalone UI layer.
   EventKillTimer();
   ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,false);
   ChartSetInteger(0,CHART_MOUSE_SCROLL,true);
   NI_DestroyPanel();
}
